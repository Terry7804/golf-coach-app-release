// 연습 기록: 폰 안(localStorage)에 저장, CSV로 내보내기(공유 → 구글 드라이브/시트 등)
import { Capacitor, registerPlugin } from './vendor/capacitor-core.js';
import { ISSUES, VIEW_NAME } from './coach.js';
import { FIELDS, CLUBS } from './shot.js';

const KEY = 'golf.sessions.v1';

export function loadSessions() {
  try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; }
}

export function saveSession(s) {
  const all = loadSessions();
  all.unshift(s);
  localStorage.setItem(KEY, JSON.stringify(all.slice(0, 200)));
}

export function deleteSession(id) {
  localStorage.setItem(KEY, JSON.stringify(loadSessions().filter((s) => s.id !== id)));
}

export function toCSV(sessions, shots = []) {
  const head = ['날짜', '촬영각도', '타석', '스윙수', '오늘고칠것', '항목코드', '항목', '측정값', '판정', '메모'];
  const rows = [head];
  for (const s of sessions) {
    const date = new Date(s.date).toLocaleString('ko-KR');
    for (const [code, m] of Object.entries(s.summary)) {
      rows.push([
        date, VIEW_NAME[s.view], s.handed === 'left' ? '좌타' : '우타', s.swings,
        s.focus ? ISSUES[s.focus].name : '', code, ISSUES[code].name,
        m.value == null ? '' : m.value.toFixed(3),
        m.status === 'ok' ? '적정' : m.status === 'low' ? '낮음' : m.status === 'high' ? '높음' : '',
        s.memo || '',
      ]);
    }
  }
  // 연습장 화면 사진에서 읽은 수치 (같은 칸 구성: 촬영각도 칸에 "연습장 화면", 오늘고칠것 칸에 클럽)
  for (const s of shots) {
    const date = new Date(s.date).toLocaleString('ko-KR');
    for (const [code, v] of Object.entries(s.values)) {
      const f = FIELDS[code];
      if (!f || v == null) continue;
      const unit = f.unit === 'speed' ? s.units?.speed : f.unit === 'dist' ? s.units?.dist : f.unit;
      rows.push([date, '연습장 화면', s.handed === 'left' ? '좌타' : '우타', '', CLUBS[s.club]?.name || '',
        'shot_' + code, f.name + (unit ? ` (${unit})` : ''), v, '', s.memo || '']);
    }
  }
  return '﻿' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n');
}

function csvCell(v) {
  const s = String(v ?? '');
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

export async function shareCSV(sessions, shots = []) {
  const csv = toCSV(sessions, shots);
  const name = `golf-record-${new Date().toISOString().slice(0, 10)}.csv`;
  if (!Capacitor.isNativePlatform()) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = name; a.click();
    return;
  }
  const Filesystem = registerPlugin('Filesystem');
  const Share = registerPlugin('Share');
  const res = await Filesystem.writeFile({ path: name, data: csv, directory: 'CACHE', encoding: 'utf8' });
  await Share.share({ title: '골프 연습 기록', url: res.uri, dialogTitle: '기록 보내기 (드라이브·시트 등)' });
}
