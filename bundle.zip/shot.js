// 연습장(스크린골프·론치모니터) 결과 화면 사진 → 숫자 읽기 → 해석.
// 글자 인식은 폰 안(Google ML Kit 한국어 모델, 플러그인 GolfOcr)에서 하므로 인터넷이 필요 없다.
// 기계마다 화면 배치가 달라 잘못 읽을 수 있으니, 읽은 값은 항상 사용자가 고칠 수 있게 보여준다.
import { Capacitor, registerPlugin } from './vendor/capacitor-core.js';
import { ISSUES } from './coach.js';

// 읽을 수치. syn: 화면에 나오는 이름(띄어쓰기·대소문자 무시). range: 말이 되는 값 범위(벗어나면 잘못 읽은 것으로 봄)
// dir: 좌우 방향이 있는 값(왼쪽 −, 오른쪽 +)
export const FIELDS = {
  club_speed: { name: '클럽 스피드', unit: 'speed', range: [10, 180], digits: 1,
    syn: ['클럽스피드', '헤드스피드', '클럽속도', '헤드속도', 'clubspeed', 'clubheadspeed', 'headspeed', 'chs'] },
  ball_speed: { name: '볼 스피드', unit: 'speed', range: [10, 220], digits: 1,
    syn: ['볼스피드', '공스피드', '볼속도', '공속도', 'ballspeed'] },
  smash: { name: '스매시 팩터', unit: '', range: [0.5, 1.6], digits: 2,
    syn: ['스매시팩터', '스매쉬팩터', '스매시', '스매쉬', '미트율', 'smashfactor', 'smash'] },
  launch_v: { name: '발사각', unit: '°', range: [-10, 70], digits: 1,
    syn: ['발사각', '탄도각', '탄도', '수직발사각', 'launchangle', 'verticallaunch', 'launchv', 'vla'] },
  launch_h: { name: '방향각', unit: '°', range: [-40, 40], digits: 1, dir: true,
    syn: ['방향각', '좌우발사각', '수평발사각', '출발방향', '출발각', 'launchdirection', 'horizontallaunch', 'launchh', 'hla', 'direction'] },
  back_spin: { name: '백스핀', unit: 'rpm', range: [0, 13000], digits: 0,
    syn: ['백스핀', '스핀량', '총스핀', 'backspin', 'spinrate', 'totalspin', 'spin'] },
  side_spin: { name: '사이드스핀', unit: 'rpm', range: [-6000, 6000], digits: 0, dir: true,
    syn: ['사이드스핀', '좌우스핀', 'sidespin'] },
  club_path: { name: '클럽 패스(궤도)', unit: '°', range: [-25, 25], digits: 1, dir: true,
    syn: ['클럽패스', '스윙궤도', '클럽궤도', '스윙패스', 'clubpath', 'swingpath', 'path'] },
  face_angle: { name: '페이스 각', unit: '°', range: [-25, 25], digits: 1, dir: true,
    syn: ['페이스각', '페이스앵글', '클럽페이스', '페이스', 'faceangle', 'face'] },
  attack_angle: { name: '어택 앵글(입사각)', unit: '°', range: [-15, 15], digits: 1,
    syn: ['어택앵글', '입사각', '진입각', '어택각', 'attackangle', 'angleofattack', 'aoa'] },
  carry: { name: '캐리', unit: 'dist', range: [1, 450], digits: 0,
    syn: ['캐리', '비거리', '캐리거리', 'carry', 'carrydistance'] },
  total: { name: '총거리', unit: 'dist', range: [1, 500], digits: 0,
    syn: ['총거리', '토탈', '전체거리', 'total', 'totaldistance'] },
};

// 클럽별 목표 범위 (초안, 티칭프로 감수 필요). 7번 아이언 / 드라이버 / 웨지 기준.
export const CLUBS = {
  driver: { name: '드라이버', launch_v: [10, 16], back_spin: [1800, 3200], smash: [1.42, 1.52], attack_angle: [-2, 5] },
  iron: { name: '아이언(7번)', launch_v: [14, 22], back_spin: [5000, 7500], smash: [1.30, 1.42], attack_angle: [-6, -1] },
  wedge: { name: '웨지', launch_v: [24, 36], back_spin: [7000, 11000], smash: [1.10, 1.28], attack_angle: [-8, -2] },
};

const SPEED_UNITS = ['m/s', 'mph', 'km/h'];
const DIST_UNITS = ['m', 'yd'];

const norm = (s) => String(s).toLowerCase().replace(/[\s·:：()\[\]._\-/]/g, '');

// ---------- 글자 인식 ----------
export function ocrAvailable() { return Capacitor.isNativePlatform(); }

// 사진 파일을 적당한 크기의 JPEG(base64)로. 브라우저가 사진 방향(EXIF)을 맞춰서 그려준다.
async function fileToBase64(file, maxSide = 2000) {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.round(img.naturalWidth * k);
    c.height = Math.round(img.naturalHeight * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return { base64: c.toDataURL('image/jpeg', 0.92).split(',')[1], preview: c.toDataURL('image/jpeg', 0.6) };
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function readPhoto(file) {
  const { base64, preview } = await fileToBase64(file);
  if (!ocrAvailable()) throw new Error('글자 인식은 폰 앱에서만 돼요');
  const Ocr = registerPlugin('GolfOcr');
  let res;
  try {
    res = await Ocr.read({ base64 });
  } catch (e) {
    const msg = String(e?.message || e);
    if (/not implemented|not available/i.test(msg)) throw new Error('새 설치 파일(APK)을 설치해야 글자 인식을 쓸 수 있어요');
    throw e;
  }
  return { ...res, preview };
}

// ---------- 숫자 찾기 ----------
// lines: [{text,left,top,right,bottom,words:[...]}] → { values: {code: number}, units: {speed, dist}, raw }
export function parseScreen(ocr) {
  const lines = (ocr.lines || []).map((l, i) => ({
    ...l, i, words: (l.words && l.words.length ? l.words : [l]),
  }));
  const allText = lines.map((l) => l.text).join('\n');
  const units = guessUnits(allText);

  // 1) 이름(라벨) 찾기: 한 줄 안에서 연속된 단어 1~3개를 붙여 이름과 비교, 가장 긴 이름 우선
  const synList = [];
  for (const [code, f] of Object.entries(FIELDS)) for (const s of f.syn) synList.push({ code, s: norm(s) });
  synList.sort((a, b) => b.s.length - a.s.length);

  const labels = [];
  for (const l of lines) {
    const used = new Array(l.words.length).fill(false);
    for (let n = 3; n >= 1; n--) {
      for (let a = 0; a + n <= l.words.length; a++) {
        if (used.slice(a, a + n).some(Boolean)) continue;
        const joined = norm(l.words.slice(a, a + n).map((w) => w.text).join(''));
        if (!joined || /^[-+]?\d/.test(joined)) continue;
        // 이름 뒤에 단위·숫자가 붙어 읽힌 경우(예: "볼스피드62.3")도 허용
        const hit = synList.find((x) => joined === x.s || (joined.startsWith(x.s) && /^[\d.+\-]|^(m|mph|rpm|km|yd|°)/.test(joined.slice(x.s.length))));
        if (!hit) continue;
        for (let k = a; k < a + n; k++) used[k] = true;
        labels.push({ code: hit.code, line: l, a, b: a + n - 1, box: unionBox(l.words.slice(a, a + n)) });
      }
    }
  }

  // 2) 숫자 찾기 (L/R, 좌/우 방향 글자 포함)
  const nums = [];
  for (const l of lines) {
    l.words.forEach((w, wi) => {
      const parsed = parseNumber(w.text, l.words[wi - 1]?.text, l.words[wi + 1]?.text);
      if (parsed) nums.push({ ...parsed, line: l, wi, box: w });
    });
  }

  // 3) 이름과 숫자 짝짓기: 같은 줄 오른쪽 > 바로 아래 > 바로 위 순으로 가까운 것. 전체에서 가까운 짝부터 확정.
  const pairs = [];
  for (const lb of labels) {
    const f = FIELDS[lb.code];
    const h = Math.max(8, lb.box.bottom - lb.box.top);
    for (const nm of nums) {
      const v = nm.dir ? nm.value * nm.dir : nm.value;
      if (!inRange(lb.code, v, units)) continue;
      let cost = null;
      if (nm.line === lb.line && nm.wi > lb.b) {
        cost = (nm.wi - lb.b) * 0.1; // 같은 줄, 이름 바로 뒤
        // 사이에 다른 이름이 있으면 그 이름의 숫자
        if (labels.some((o) => o !== lb && o.line === lb.line && o.a > lb.b && o.a < nm.wi)) cost = null;
      } else if (nm.line === lb.line && nm.wi >= lb.a && nm.wi <= lb.b) {
        cost = 0; // "볼스피드62.3"처럼 붙어 읽힘
      } else {
        const cx = (lb.box.left + lb.box.right) / 2, ncx = (nm.box.left + nm.box.right) / 2;
        const cy = (lb.box.top + lb.box.bottom) / 2, ncy = (nm.box.top + nm.box.bottom) / 2;
        const w = Math.max(lb.box.right - lb.box.left, nm.box.right - nm.box.left);
        const dx = Math.abs(ncx - cx), dy = ncy - cy;
        if (dx < w * 0.9 && dy > 0 && dy < h * 5) cost = 1 + dy / h;          // 아래
        else if (dx < w * 0.9 && dy < 0 && -dy < h * 4) cost = 2 + -dy / h;   // 위
        else if (Math.abs(dy) < h * 0.8 && nm.box.left > lb.box.right && nm.box.left - lb.box.right < h * 8) cost = 1.5 + (nm.box.left - lb.box.right) / h / 4; // 오른쪽
      }
      if (cost != null) pairs.push({ lb, nm, v, cost });
    }
  }
  pairs.sort((a, b) => a.cost - b.cost);
  const values = {}, usedNum = new Set(), usedLabel = new Set();
  for (const p of pairs) {
    if (usedNum.has(p.nm) || usedLabel.has(p.lb) || values[p.lb.code] != null) continue;
    usedNum.add(p.nm); usedLabel.add(p.lb);
    values[p.lb.code] = p.v;
  }
  if (values.smash == null && values.ball_speed && values.club_speed) {
    values.smash = Math.round(values.ball_speed / values.club_speed * 100) / 100;
  }
  return { values, units, raw: allText, found: labels.length };
}

function unionBox(ws) {
  return {
    left: Math.min(...ws.map((w) => w.left)), top: Math.min(...ws.map((w) => w.top)),
    right: Math.max(...ws.map((w) => w.right)), bottom: Math.max(...ws.map((w) => w.bottom)),
  };
}

const LEFT_RE = /^(l|left|좌|왼|왼쪽|훅|in)$/i, RIGHT_RE = /^(r|right|우|오|오른쪽)$/i;

export function parseNumber(text, prev, next) {
  const t = String(text).replace(/,(?=\d{3}(?!\d))/g, '').replace(/[Oo](?=\d)|(?<=\d)[Oo]/g, '0');
  const m = t.match(/^([LRlr좌우]?)\s*([-+−]?\d+(?:\.\d+)?)\s*([LRlr좌우](?![a-zA-Z])|)/) || t.match(/([-+−]?\d+(?:\.\d+)?)/);
  if (!m) return null;
  let numStr, pre = '', post = '';
  if (m.length >= 4) { pre = m[1]; numStr = m[2]; post = m[3]; } else numStr = m[1];
  // 숫자보다 글자가 훨씬 많은 단어(예: "7번아이언")는 숫자로 보지 않음
  const letters = t.replace(/[\d.,+\-−°%\s]|mph|m\/s|km\/h|rpm|yd|yds|m$/gi, '');
  if (letters.length > 2 && !/^[LRlr좌우]$/.test(letters)) return null;
  let value = Number(numStr.replace('−', '-'));
  if (!isFinite(value)) return null;
  let dir = 0;
  const side = pre || post;
  if (side) dir = /[Ll좌]/.test(side) ? -1 : 1;
  else if (prev && LEFT_RE.test(prev.trim())) dir = -1;
  else if (prev && RIGHT_RE.test(prev.trim())) dir = 1;
  else if (next && LEFT_RE.test(next.trim())) dir = -1;
  else if (next && RIGHT_RE.test(next.trim())) dir = 1;
  if (dir) value = Math.abs(value);
  return { value, dir: dir || 0 };
}

function guessUnits(text) {
  const t = text.toLowerCase();
  const speed = /mph/.test(t) ? 'mph' : /km\/?h/.test(t) ? 'km/h' : 'm/s';
  const dist = /\byds?\b|yard|야드/.test(t) ? 'yd' : 'm';
  return { speed, dist };
}

function inRange(code, v, units) {
  const f = FIELDS[code];
  let [lo, hi] = f.range;
  if (f.unit === 'speed') {
    const k = units.speed === 'mph' ? 1 : units.speed === 'km/h' ? 1.6 : 0.45;
    hi *= k; lo *= k;
  }
  return v >= lo && v <= hi;
}

// ---------- 해석 ----------
// 화면 수치 → 쉬운 말 진단 + 관련 자세 항목. handed: 'right' | 'left'
// 방향 값은 오른손잡이 기준(오른쪽 +). 왼손잡이는 좌우를 뒤집어 같은 규칙으로 판단.
export function interpret(values, club, handed) {
  const v = { ...values };
  const flip = handed === 'left' ? -1 : 1;
  for (const k of ['launch_h', 'side_spin', 'club_path', 'face_angle']) if (v[k] != null) v[k] *= flip;
  const target = CLUBS[club] || CLUBS.iron;
  const notes = []; // { level: 'good'|'bad'|'info', text, related: [ISSUES code] }

  if (v.smash == null && v.ball_speed && v.club_speed) v.smash = v.ball_speed / v.club_speed;
  if (v.smash != null) {
    const [lo] = target.smash;
    if (v.smash < lo - 0.05) notes.push({ level: 'bad', text: `공을 클럽 가운데에 잘 못 맞혔어요(스매시 ${v.smash.toFixed(2)}, ${target.name} 목표 ${lo} 이상). 뒤땅·토핑이나 끝에 맞는 경우예요.`, related: ['head_height', 'spine_maintain', 'finish_balance'] });
    else if (v.smash >= lo) notes.push({ level: 'good', text: `정타율 좋아요(스매시 ${v.smash.toFixed(2)}).` });
  }

  if (v.launch_v != null) {
    const [lo, hi] = target.launch_v;
    if (v.launch_v < lo) notes.push({ level: 'bad', text: `공이 낮게 떠요(발사각 ${v.launch_v.toFixed(1)}°, 목표 ${lo}~${hi}°).`, related: club === 'driver' ? ['spine_maintain', 'weight_shift'] : ['head_height', 'spine_maintain'] });
    else if (v.launch_v > hi) notes.push({ level: 'bad', text: `공이 너무 높이 떠요(발사각 ${v.launch_v.toFixed(1)}°, 목표 ${lo}~${hi}°). 손목으로 퍼 올리거나 체중이 뒤에 남는 경우가 많아요.`, related: ['weight_shift', 'head_sway'] });
    else notes.push({ level: 'good', text: `발사각 적당해요(${v.launch_v.toFixed(1)}°).` });
  }

  if (v.back_spin != null) {
    const [lo, hi] = target.back_spin;
    if (v.back_spin > hi) notes.push({ level: 'bad', text: `백스핀이 많아요(${Math.round(v.back_spin)}rpm, 목표 ${lo}~${hi}). 공이 뜨기만 하고 거리가 덜 나요.`, related: club === 'driver' ? ['spine_maintain'] : ['weight_shift'] });
    else if (v.back_spin < lo) notes.push({ level: 'bad', text: `백스핀이 적어요(${Math.round(v.back_spin)}rpm, 목표 ${lo}~${hi}). 공이 일찍 떨어지거나 그린에 안 서요.`, related: [] });
  }

  if (v.attack_angle != null) {
    const [lo, hi] = target.attack_angle;
    if (v.attack_angle < lo) notes.push({ level: 'bad', text: `너무 가파르게 내려쳐요(어택 앵글 ${v.attack_angle.toFixed(1)}°).`, related: ['head_sway', 'spine_maintain'] });
    else if (v.attack_angle > hi) notes.push({ level: 'bad', text: `클럽이 올라가면서 맞아요(어택 앵글 ${v.attack_angle.toFixed(1)}°). ${club === 'driver' ? '' : '아이언은 살짝 내려치며 맞아야 해요. '}체중이 뒤에 남는 경우가 많아요.`, related: ['weight_shift', 'head_sway'] });
  }

  // 공 휘어짐: 궤도(패스)와 페이스 차이
  if (v.club_path != null) {
    if (v.club_path < -4) notes.push({ level: 'bad', text: `아웃-인 궤도예요(클럽 패스 왼쪽 ${Math.abs(v.club_path).toFixed(1)}°). 슬라이스나 당겨치는 공의 가장 흔한 원인이에요.`, related: ['weight_shift', 'posture_tilt', 'tempo'] });
    else if (v.club_path > 5) notes.push({ level: 'bad', text: `인-아웃이 심해요(클럽 패스 오른쪽 ${v.club_path.toFixed(1)}°). 밀리는 공이나 훅이 나기 쉬워요.`, related: ['head_sway', 'weight_shift'] });
    else notes.push({ level: 'good', text: `스윙 궤도 괜찮아요(클럽 패스 ${fmtField('club_path', values.club_path)}).` });
  }
  if (v.club_path != null && v.face_angle != null) {
    const f2p = v.face_angle - v.club_path;
    if (f2p > 3) notes.push({ level: 'bad', text: `페이스가 궤도보다 열려 맞아요(${f2p.toFixed(1)}°) → 공이 ${handed === 'left' ? '왼쪽' : '오른쪽'}으로 휘어요(페이드·슬라이스).`, related: ['lead_arm'] });
    else if (f2p < -3) notes.push({ level: 'bad', text: `페이스가 궤도보다 닫혀 맞아요(${Math.abs(f2p).toFixed(1)}°) → 공이 ${handed === 'left' ? '오른쪽' : '왼쪽'}으로 휘어요(드로우·훅).`, related: ['lead_arm'] });
    else notes.push({ level: 'good', text: '페이스와 궤도가 잘 맞아서 공이 크게 휘지 않아요.' });
  } else if (v.face_angle != null && Math.abs(v.face_angle) > 4) {
    notes.push({ level: 'bad', text: `페이스가 ${v.face_angle > 0 ? '열려' : '닫혀'} 맞아요(${Math.abs(v.face_angle).toFixed(1)}°).`, related: ['lead_arm'] });
  } else if (v.side_spin != null && Math.abs(v.side_spin) > 800) {
    notes.push({ level: 'bad', text: `사이드스핀이 커서(${Math.round(Math.abs(v.side_spin))}rpm) 공이 ${(v.side_spin > 0) === (handed !== 'left') ? '오른쪽' : '왼쪽'}으로 많이 휘어요.`, related: ['weight_shift', 'lead_arm'] });
  }
  if (v.launch_h != null && Math.abs(v.launch_h) > 6) {
    notes.push({ level: 'bad', text: `공이 처음부터 ${(v.launch_h > 0) === (handed !== 'left') ? '오른쪽' : '왼쪽'}으로 출발해요(${Math.abs(v.launch_h).toFixed(1)}°). 출발 방향은 주로 페이스 방향이 결정해요.`, related: ['lead_arm', 'stance_width'] });
  }

  if (!notes.length) notes.push({ level: 'info', text: '해석할 수 있는 수치가 부족해요. 아래 칸에 직접 넣어 주세요.' });
  return notes;
}

export function fmtField(code, v, units) {
  if (v == null || !isFinite(v)) return '-';
  const f = FIELDS[code];
  const n = Number(v).toFixed(f.digits);
  if (f.dir) return Math.abs(v) < 1e-9 ? `0${f.unit}` : `${v < 0 ? '왼쪽' : '오른쪽'} ${Math.abs(v).toFixed(f.digits)}${f.unit}`;
  if (f.unit === 'speed') return `${n} ${units?.speed || 'm/s'}`;
  if (f.unit === 'dist') return `${n} ${units?.dist || 'm'}`;
  return f.unit ? `${n}${f.unit === 'rpm' ? ' rpm' : f.unit}` : n;
}

// ---------- 저장 ----------
const KEY = 'golf.shots.v1';
export function loadShots() {
  try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; }
}
export function saveShot(s) {
  const all = loadShots();
  all.unshift(s);
  localStorage.setItem(KEY, JSON.stringify(all.slice(0, 300)));
}
export function deleteShot(id) {
  localStorage.setItem(KEY, JSON.stringify(loadShots().filter((s) => s.id !== id)));
}

// 오늘 영상 분석 기록 중 벗어난 자세 항목과 연결
export function relatedToday(notes, sessions) {
  const today = new Date().toDateString();
  const todays = sessions.filter((s) => new Date(s.date).toDateString() === today);
  const bad = new Set();
  for (const s of todays) for (const [c, m] of Object.entries(s.summary || {})) if (m.status === 'low' || m.status === 'high') bad.add(c);
  const related = new Set(notes.flatMap((n) => n.related || []));
  return { both: [...related].filter((c) => bad.has(c) && ISSUES[c]), related: [...related].filter((c) => ISSUES[c]), hasToday: todays.length > 0 };
}

export { SPEED_UNITS, DIST_UNITS };
