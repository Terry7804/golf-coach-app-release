// 자동 업데이트: 앱을 켤 때 공개 배포 저장소의 latest.json을 보고
// 더 새 빌드가 있으면 화면 파일 묶음(zip)을 받아 두었다가 적용한다.
const LATEST_URL =
  'https://raw.githubusercontent.com/Terry7804/golf-coach-app-release/main/latest.json';

import { Capacitor, registerPlugin } from './vendor/capacitor-core.js';

const isNative = Capacitor.isNativePlatform();
const Updater = isNative ? registerPlugin('CapacitorUpdater') : null;

export async function currentBuild() {
  try {
    const res = await fetch('./version.json', { cache: 'no-store' });
    const v = await res.json();
    return Number(v.build) || 0;
  } catch {
    return 0; // 노트북에서 직접 열었을 때 등
  }
}

// 새 화면이 정상적으로 떴다고 알려 준다. 10초 안에 이걸 못 부르면
// (새 버전이 고장 난 경우) 플러그인이 이전 버전으로 되돌린다.
export async function markReady() {
  if (!Updater) return;
  try { await Updater.notifyAppReady(); } catch (e) { console.warn('notifyAppReady 실패', e); }
}

let latestApk = null;

export async function checkForUpdate(bannerEl) {
  if (!Updater) return;
  try {
    const mine = await currentBuild();
    const res = await fetch(LATEST_URL + '?t=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) return;
    const latest = await res.json();
    latestApk = latest.apk || null;
    if (!(Number(latest.build) > mine) || !latest.bundle) return;

    showBanner(bannerEl, `새 버전(빌드 ${latest.build})을 받는 중… 0%`);
    let listener = null;
    try {
      listener = await Updater.addListener('download', (info) => {
        if (info?.percent != null) showBanner(bannerEl, `새 버전(빌드 ${latest.build})을 받는 중… ${Math.round(info.percent)}%`);
      });
    } catch { /* 진행률 표시는 없어도 됨 */ }
    // 3분 안에 끝나지 않으면 포기하고 지금 버전을 계속 쓴다
    const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error('3분 안에 받지 못했어요')), 180000));
    let bundle;
    try {
      bundle = await Promise.race([
        Updater.download({ url: latest.bundle, version: String(latest.build), checksum: latest.checksum || '' }),
        timeout,
      ]);
    } finally {
      try { await listener?.remove(); } catch { /* 무시 */ }
    }
    await Updater.next({ id: bundle.id }); // 다음에 앱을 켤 때 자동 적용

    const notes = latest.notes ? `<br><small>${escapeHtml(latest.notes)}</small>` : '';
    showBanner(
      bannerEl,
      `새 버전(빌드 ${latest.build})이 준비됐어요.${notes}`,
      { label: '지금 적용', onClick: () => Updater.set({ id: bundle.id }) },
    );
  } catch (e) {
    console.warn('업데이트 실패', e);
    // 실패 이유를 보여주고 닫기 버튼 제공 (지금 버전은 그대로 쓸 수 있음)
    const apk = latestApk ? ' 최신 설치 파일을 직접 받아 설치해도 돼요.' : '';
    showBanner(bannerEl, `업데이트를 받지 못했어요: ${escapeHtml(e?.message || e)}.${apk}`,
      { label: '닫기', onClick: () => hideBanner(bannerEl) });
  }
}

function showBanner(el, html, action) {
  el.hidden = false;
  el.innerHTML = `<span>${html}</span>`;
  if (action) {
    const btn = document.createElement('button');
    btn.textContent = action.label;
    btn.addEventListener('click', action.onClick);
    el.appendChild(btn);
  }
}

function hideBanner(el) { el.hidden = true; }

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
