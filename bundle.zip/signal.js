// 손 신호: 손바닥을 카메라에 보여 주거나(또는 한 손을 머리 위로 들면) 스윙 시작/끝 신호.
// 멀리(3~4m) 서 있으면 손이 작게 보여서, 관절(손목) 위치 주변을 잘라 크게 키운 뒤 손 모양을 판별한다.
import { FilesetResolver, GestureRecognizer } from './vendor/tasks-vision/vision_bundle.js';

const NOSE = 0, LSH = 11, RSH = 12, LWR = 15, RWR = 16, LIDX = 19, RIDX = 20, LHIP = 23, RHIP = 24;

let recognizer = null, loading = null;
export async function loadPalm(delegate = 'GPU') {
  if (recognizer) return recognizer;
  if (loading) return loading;
  loading = (async () => {
    const vision = await FilesetResolver.forVisionTasks(new URL('./vendor/tasks-vision/wasm', location.href).href);
    const make = (d) => GestureRecognizer.createFromOptions(vision, {
      baseOptions: { modelAssetPath: new URL('./models/gesture_recognizer.task', location.href).href, delegate: d },
      runningMode: 'IMAGE', numHands: 1,
      minHandDetectionConfidence: 0.4, minHandPresenceConfidence: 0.4,
    });
    try { recognizer = await make(delegate); } catch (e) { console.warn('손 모양 GPU 실패', e); recognizer = await make('CPU'); }
    return recognizer;
  })();
  try { return await loading; } catch (e) { loading = null; throw e; }
}

// 한 손만 머리 위(코보다 위)로 들고, 다른 손은 어깨 아래 → 신호. 피니시(두 손이 같이 높음)와 구별된다.
export function handRaised(lm) {
  const headY = lm[NOSE].y, shY = (lm[LSH].y + lm[RSH].y) / 2;
  const torso = Math.abs((lm[LHIP].y + lm[RHIP].y) / 2 - shY) || 0.2;
  const up = (w) => lm[w].y < headY - torso * 0.1;
  const down = (w) => lm[w].y > shY;
  return (up(LWR) && down(RWR)) || (up(RWR) && down(LWR));
}

const crop = document.createElement('canvas');
crop.width = crop.height = 192;
const cctx = crop.getContext('2d');

// 손목 주변을 잘라서 손바닥(Open_Palm)인지 본다. side: 0 왼손, 1 오른손
export function palmAt(src, lm, side) {
  if (!recognizer) return false;
  const W = src.width, H = src.height;
  const wr = lm[side ? RWR : LWR], ix = lm[side ? RIDX : LIDX];
  if ((wr.visibility ?? 1) < 0.3) return false;
  const shY = (lm[LSH].y + lm[RSH].y) / 2, hipY = (lm[LHIP].y + lm[RHIP].y) / 2;
  const torsoPx = Math.abs(hipY - shY) * H;
  const size = Math.max(64, torsoPx * 0.9);
  // 손 중심은 손목에서 손가락 쪽으로 조금 이동
  const cx = (wr.x + (ix.x - wr.x) * 0.8) * W, cy = (wr.y + (ix.y - wr.y) * 0.8) * H;
  cctx.fillStyle = '#000';
  cctx.fillRect(0, 0, 192, 192);
  cctx.drawImage(src, cx - size / 2, cy - size / 2, size, size, 0, 0, 192, 192);
  let r;
  try { r = recognizer.recognize(crop); } catch { return false; }
  const g = r?.gestures?.[0]?.[0];
  return !!g && g.categoryName === 'Open_Palm' && g.score > 0.5;
}

// 매 프레임 호출. 손바닥은 3장마다 한 번(왼손·오른손 번갈아) 확인해 속도를 아낀다.
// 신호가 0.4초 이상 이어지면 true를 한 번 돌려준다(1.5초 동안은 다시 안 받음).
export function makeSignal() {
  let n = 0, since = -1, lastSeen = -1, lastFire = -10, palmSeen = -10;
  return function step(src, lm, t) {
    n++;
    if (recognizer && n % 3 === 0 && palmAt(src, lm, (n / 3) % 2)) palmSeen = t;
    const on = handRaised(lm) || t - palmSeen < 0.35;
    if (on) {
      if (since < 0 || t - lastSeen > 0.35) since = t;
      lastSeen = t;
      if (t - since >= 0.4 && t - lastFire > 1.5) { lastFire = t; since = -1; return true; }
    }
    return false;
  };
}
