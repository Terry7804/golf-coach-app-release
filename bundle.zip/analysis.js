// 프레임별 관절 좌표 → 스윙 나누기 → 촬영 각도 → 항목 측정
import { ISSUES, judge } from './coach.js';

// MediaPipe 관절 번호
const NOSE = 0, LSH = 11, RSH = 12, LEL = 13, REL = 14, LWR = 15, RWR = 16,
  LHIP = 23, RHIP = 24, LKN = 25, RKN = 26, LAN = 27, RAN = 28;

const median = (a) => {
  const s = a.filter((v) => v != null && isFinite(v)).sort((x, y) => x - y);
  if (!s.length) return null;
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
const mid = (p, q) => ({ x: (p.x + q.x) / 2, y: (p.y + q.y) / 2, z: ((p.z || 0) + (q.z || 0)) / 2 });
const dist2 = (p, q) => Math.hypot(p.x - q.x, p.y - q.y);
const deg = (r) => (r * 180) / Math.PI;

// 세 점 각도 (b가 꼭짓점), world 좌표(3D)
function angle3(a, b, c) {
  const u = [a.x - b.x, a.y - b.y, a.z - b.z];
  const v = [c.x - b.x, c.y - b.y, c.z - b.z];
  const dot = u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
  const nu = Math.hypot(...u), nv = Math.hypot(...v);
  if (!nu || !nv) return null;
  return deg(Math.acos(Math.max(-1, Math.min(1, dot / (nu * nv)))));
}

// frames: [{t, lm:[33], wl:[33]}], W/H: 영상 크기(px)
// 스윙별 측정값 목록 → 항목별 중앙값·판정 (촬영 각도에 맞는 항목만)
export function summarize(perSwing, view) {
  const summary = {};
  for (const [code, d] of Object.entries(ISSUES)) {
    const precise = d.views.includes(view);
    if (!precise && !d.est3d) continue;
    const vals = perSwing.map((m) => m[code]).filter((x) => x != null && isFinite(x));
    if (!vals.length) continue;
    const value = median(vals);
    const j = judge(code, value);
    const repeat = vals.filter((x) => judge(code, x).status !== 'ok').length / vals.length;
    summary[code] = { value, status: j.status, dist: j.dist, repeat, n: vals.length, est: !precise };
  }
  return summary;
}

// opts.noFallback: 실시간 모드에서는 보조 분할(오탐 위험)을 쓰지 않는다
export function analyze(frames, W, H, handed, opts = {}) {
  const px = (p) => ({ x: p.x * W, y: p.y * H });
  const F = frames.map((f) => {
    const L = f.lm.map(px);
    const sh = mid(L[LSH], L[RSH]), hip = mid(L[LHIP], L[RHIP]);
    return { t: f.t, L, W: f.wl, sh, hip, wr: mid(L[LWR], L[RWR]), torso: dist2(sh, hip) };
  });
  if (F.length < 15) return { error: '관절을 찾은 화면이 너무 적어요. 몸 전체가 보이게 다시 찍어 주세요.' };

  const torso = median(F.map((f) => f.torso));
  // 손 높이(몸통 길이 단위, 위로 갈수록 +)와 속도
  const hRaw = F.map((f) => (f.hip.y - f.wr.y) / torso);
  const h = smooth(hRaw, 2);
  const v = h.map((_, i) => {
    const a = Math.max(0, i - 1), b = Math.min(h.length - 1, i + 1);
    const dt = F[b].t - F[a].t;
    return dt > 0 ? (h[b] - h[a]) / dt : 0;
  });

  const swings = segment(F, h, v, opts);
  if (!swings.length) {
    const hs = h.slice().sort((a, b) => a - b);
    const diag = `진단: 관절 화면 ${F.length}개, 손 높이 ${hs[0].toFixed(1)}~${hs[hs.length - 1].toFixed(1)}, 최대 하강 속도 ${Math.min(...v).toFixed(1)}`;
    return { error: '스윙을 찾지 못했어요. 몸 전체가 보이고 스윙이 처음부터 끝까지 담기게 찍어 주세요.\n' + diag };
  }

  const view = detectView(F, swings, torso);
  const lead = handed === 'left'
    ? { sh: RSH, el: REL, wr: RWR, hip: RHIP, kn: RKN, an: RAN, tsh: LSH }
    : { sh: LSH, el: LEL, wr: LWR, hip: LHIP, kn: LKN, an: LAN, tsh: RSH };

  const perSwing = swings.map((s) => measure(F, s, lead, torso, view.view));

  const summary = summarize(perSwing, view.view);
  return { swings, perSwing, view, summary, torso };
}

function smooth(a, k) {
  return a.map((_, i) => {
    let s = 0, n = 0;
    for (let j = i - k; j <= i + k; j++) if (j >= 0 && j < a.length) { s += a[j]; n++; }
    return s / n;
  });
}

// 빠른 하강 구간 → 직전 최고점 = 탑, 이후 최저점 = 임팩트, 이후 정지 = 피니시, 탑 이전 정지 = 어드레스
function segment(F, h, v, opts = {}) {
  const idxAt = (t) => { let i = 0; while (i < F.length - 1 && F[i].t < t) i++; return i; };
  // 슬로모션 영상도 잡히도록, 영상 안에서 가장 빠른 하강 속도를 기준으로 문턱값을 정한다
  const vmin = Math.min(...v);
  const thr = Math.min(-0.8, vmin * 0.45);
  const events = [];
  for (let i = 0; i < F.length; i++) {
    if (v[i] < thr) {
      let j = i; while (j + 1 < F.length && v[j + 1] < thr) j++;
      events.push([i, j]); i = j;
    }
  }
  const swings = [];
  let lastImpactT = -Infinity;
  for (const [s, e] of events) {
    if (F[s].t - lastImpactT < 2) continue; // 스윙 간 최소 2초
    // 탑: 하강 시작 직전 3초 안의 최고점
    const t0 = idxAt(F[s].t - 3);
    let top = s; for (let i = t0; i <= s; i++) if (h[i] > h[top]) top = i;
    // 임팩트: 하강 이후 1초 안의 최저점
    const t1 = idxAt(F[e].t + 1);
    let imp = e; for (let i = e; i <= t1; i++) if (h[i] < h[imp]) imp = i;
    // 어드레스: 탑 이전 5초 안의 최저점(손이 낮고 멈춘 곳)
    const t2 = idxAt(F[top].t - 5);
    let adr = top; for (let i = t2; i <= top; i++) if (h[i] < h[adr]) adr = i;
    // 테이크어웨이: 어드레스 이후 손이 오르기 시작한 지점
    const thr = h[adr] + 0.1 * (h[top] - h[adr]);
    let take = adr; while (take < top && h[take] < thr) take++;
    // 피니시: 임팩트 0.3초 후부터 손이 높고 거의 멈춘 첫 지점
    let fin = -1, finStill = false;
    for (let i = idxAt(F[imp].t + 0.3); i < F.length; i++) {
      if (F[i].t - F[imp].t > 4) break;
      if (h[i] > 0.5 && Math.abs(v[i]) < Math.max(0.3, -thr * 0.25)) { fin = i; finStill = true; break; }
    }
    if (fin < 0) {
      const t3 = idxAt(F[imp].t + 3); fin = imp;
      for (let i = imp; i <= t3; i++) if (h[i] > h[fin]) fin = i;
    }
    const back = F[top].t - F[take].t, down = F[imp].t - F[top].t;
    const ok = h[top] - h[imp] > 0.6 && back > 0.2 && back < 6 && down > 0.08 && down < 2;
    if (!ok) continue;
    if (opts.strict && !isRealSwing(F, h, v, { adr, take, top, imp, fin }, idxAt, opts)) continue;
    swings.push({ adr, take, top, imp, fin, tempo: back / down, finStill });
    lastImpactT = F[imp].t;
  }
  if (!swings.length && !opts.noFallback) { const s = fallbackSwing(F, h, v, idxAt); if (s) swings.push(s); }
  return swings;
}

// 실시간 연습용 확인: 어드레스(손 모으고 거의 멈춤) → 백스윙(손이 올라감) → 빠른 다운스윙 →
// 임팩트(손이 어드레스 높이 근처로 돌아옴) → 피니시(손이 다시 올라감)가 있어야 스윙으로 센다.
// 걷기, 팔 흔들기, 클럽 들고 서성이기 같은 움직임을 거르기 위함.
// v2.7 기준이 폰에서 너무 엄격해 진짜 스윙도 못 셈 → v2.9에서 완화(관절 떨림·왜글 허용, 피니시 멈춤 불필요).
// opts.why 배열이 있으면 거른 이유와 실제 값을 넣는다(화면에 표시해 기준 조정에 씀).
export const STRICT_EXACT = {
  addrStill: 0.4,   // 어드레스로 볼 구간 길이(초)
  addrMaxV: 1.2,    // 그 구간 손 속도 중앙값 상한(몸통 길이/초). 떨림·왜글은 허용
  addrMaxH: 0.7,    // 어드레스 손 높이 상한(골반 위로 몸통의 70%까지)
  handsGap: 0.7,    // 두 손 사이 거리 상한(몸통 길이 단위, 중앙값): 클럽을 두 손으로 잡고 있어야 함
  topMinH: 0.55,    // 탑에서 손 높이 하한(어깨 높이 ≈ 1, 하프스윙 허용)
  impBack: 0.7,     // 임팩트 손 높이가 어드레스 높이에서 벗어나도 되는 폭
  downMax: 1.5,     // 다운스윙 최대 시간(초)
  feetMove: 0.6,    // 어드레스~임팩트 사이 발 이동 상한(몸통 길이 단위): 걸어 다니면 안 됨
  finRise: 0.3,     // 임팩트 후 2초 안에 손이 올라가야 하는 높이
  topGap: 1.0,      // 탑에서 두 손 사이 거리 상한
  impMinH: -1.0,    // 임팩트 손 높이 하한: 공 꽂으러 숙이거나 바닥에 손이 닿는 동작을 거름
  needAddr: true,   // 어드레스 구간(멈춤) 확인
};
// 보통(v2.10): 정확은 폰에서 너무 빡빡, 느슨은 다른 동작도 셈 → 그 중간.
// 어드레스는 "계속 흔들지만 않으면" 통과, 오인식 원인이 되는 동작(숙이기·걷기·한 팔·작은 동작)만 거른다.
export const STRICT_NORMAL = {
  ...STRICT_EXACT,
  needAddr: false,
  addrMaxV: 2.0, // 계속 팔을 흔드는 동작만 거르고 왜글은 허용
  addrMaxH: 0.9, handsGap: 1.0, topMinH: 0.45, impBack: 0.9, finRise: 0.2,
};
export const STRICT = STRICT_EXACT; // 예전 이름 호환

function isRealSwing(F, h, v, s, idxAt, opts) {
  const STRICT = opts.strict === 'normal' ? STRICT_NORMAL : STRICT_EXACT;
  const f2 = (x) => x.toFixed(2);
  const why = (m) => { if (opts.why) opts.why.push(m); return false; };
  const torso = median(F.map((f) => f.torso)) || 1;
  const gap = (i) => dist2(F[i].L[LWR], F[i].L[RWR]) / torso;
  // 1) 어드레스: 손이 움직이기 시작한 지점 직전 구간의 손 속도·높이·간격(중앙값)
  let st = s.take;
  while (st > 0 && v[st] > 0.3) st--;
  const a0 = idxAt(F[st].t - STRICT.addrStill);
  if (STRICT.needAddr && F[st].t - F[a0].t < STRICT.addrStill * 0.6) return why('어드레스 전 화면 부족');
  const seg = []; for (let i = a0; i <= st; i++) seg.push(i);
  const mv = median(seg.map((i) => Math.abs(v[i]))), mh = median(seg.map((i) => h[i])), mg = median(seg.map(gap));
  if (mv > STRICT.addrMaxV) return why(`어드레스에서 멈추지 않음 (손 속도 ${f2(mv)} > ${STRICT.addrMaxV})`);
  if (mh > STRICT.addrMaxH) return why(`어드레스 손이 높음 (${f2(mh)} > ${STRICT.addrMaxH})`);
  if (mg > STRICT.handsGap) return why(`어드레스에서 두 손이 떨어짐 (${f2(mg)} > ${STRICT.handsGap})`);
  // 2) 탑: 손이 충분히 올라감
  if (h[s.top] < STRICT.topMinH) return why(`백스윙이 낮음 (${f2(h[s.top])} < ${STRICT.topMinH})`);
  // 2-1) 탑에서도 두 손이 모여 있음 (한 팔만 휘두른 경우 거름, 관절 떨림 감안해 넉넉히)
  if (gap(s.top) > STRICT.topGap) return why(`탑에서 두 손이 떨어짐 (${f2(gap(s.top))} > ${STRICT.topGap})`);
  // 3) 임팩트: 손이 바닥 쪽까지 내려가지 않음(공 꽂기·줍기 거름), 어드레스 높이 근처로 돌아옴
  if (h[s.imp] < STRICT.impMinH) return why(`손이 너무 낮게 내려감 (${f2(h[s.imp])} < ${STRICT.impMinH}, 숙이는 동작)`);
  const di = Math.abs(h[s.imp] - mh);
  if (di > STRICT.impBack) return why(`임팩트 높이가 어드레스와 다름 (차이 ${f2(di)} > ${STRICT.impBack})`);
  // 4) 다운스윙이 빠름
  const dn = F[s.imp].t - F[s.top].t;
  if (dn > STRICT.downMax) return why(`다운스윙이 느림 (${dn.toFixed(1)}초)`);
  // 5) 발이 거의 그대로 (걷는 동작 거름)
  const ank = (i) => mid(F[i].L[LAN], F[i].L[RAN]);
  const fm = dist2(ank(s.adr), ank(s.imp)) / torso;
  if (fm > STRICT.feetMove) return why(`발이 움직임 (${f2(fm)} > ${STRICT.feetMove})`);
  // 6) 피니시: 임팩트 후 손이 다시 올라감
  const t2 = idxAt(F[s.imp].t + 2);
  let up = -Infinity; for (let i = s.imp; i <= t2; i++) up = Math.max(up, h[i]);
  if (up < STRICT.finRise) return why(`피니시까지 안 감 (손 높이 ${f2(up)} < ${STRICT.finRise})`);
  return true;
}

// 보조 방법: 빠른 하강을 못 잡았을 때(다운스윙 순간 관절을 놓친 경우 등)
// 손이 가장 높은 곳 = 탑, 그 뒤 3초 안의 가장 낮은 곳 = 임팩트로 스윙 하나를 만든다
function fallbackSwing(F, h, v, idxAt) {
  let top = 0;
  for (let i = 1; i < F.length; i++) if (h[i] > h[top]) top = i;
  const t1 = idxAt(F[top].t + 3);
  let imp = top; for (let i = top; i <= t1; i++) if (h[i] < h[imp]) imp = i;
  const t2 = idxAt(F[top].t - 5);
  let adr = top; for (let i = t2; i <= top; i++) if (h[i] < h[adr]) adr = i;
  if (imp === top || adr === top || h[top] - h[imp] < 0.6 || h[top] - h[adr] < 0.6) return null;
  const thr = h[adr] + 0.1 * (h[top] - h[adr]);
  let take = adr; while (take < top && h[take] < thr) take++;
  const t3 = idxAt(F[imp].t + 3);
  let fin = imp; for (let i = imp; i <= t3; i++) if (h[i] > h[fin]) fin = i;
  const back = F[top].t - F[take].t, down = F[imp].t - F[top].t;
  if (!(back > 0 && down > 0)) return null;
  return { adr, take, top, imp, fin, tempo: back / down, fallback: true };
}

// 어드레스 때 어깨너비/몸통 비율(이미지)과 어깨·골반 yaw(world)로 촬영 각도 판단
function detectView(F, swings, torso) {
  const ratios = [], yawS = [], yawH = [];
  for (const s of swings) {
    for (let i = Math.max(0, s.adr - 3); i <= Math.min(F.length - 1, s.adr + 3); i++) {
      const f = F[i];
      ratios.push(dist2(f.L[LSH], f.L[RSH]) / torso);
      const a = f.W[LSH], b = f.W[RSH], c = f.W[LHIP], d = f.W[RHIP];
      yawS.push(deg(Math.atan2(Math.abs(a.z - b.z), Math.abs(a.x - b.x))));
      yawH.push(deg(Math.atan2(Math.abs(c.z - d.z), Math.abs(c.x - d.x))));
    }
  }
  const r = median(ratios), ys = median(yawS), yh = median(yawH);
  const yaw = (ys + yh) / 2;
  const byYaw = yaw <= 20 ? 'front' : yaw >= 70 ? 'side' : yaw >= 30 && yaw <= 60 ? 'diag' : 'unknown';
  const byRatio = r >= 0.6 ? 'front' : r <= 0.3 ? 'side' : 'diag';
  // 이미지 비율이 더 안정적이라 기본으로 쓰고, world yaw와 맞으면 신뢰도 높음
  const view = byRatio;
  const agree = byYaw === byRatio;
  const conf = agree && Math.abs(ys - yh) < 15 ? '높음' : agree || byYaw === 'unknown' ? '보통' : '낮음';
  return { view, conf, yaw: Math.round(yaw), ratio: r };
}

function tilt(f) { // 골반→어깨 선과 수직선의 각 (이미지)
  return deg(Math.atan2(Math.abs(f.sh.x - f.hip.x), f.hip.y - f.sh.y));
}

// 3D(world) 좌표로 골반→어깨 선과 수직축(y)의 각: 촬영 각도와 거의 무관한 추정값
function tiltW(f) {
  const s = mid(f.W[LSH], f.W[RSH]), h = mid(f.W[LHIP], f.W[RHIP]);
  const dx = s.x - h.x, dy = s.y - h.y, dz = s.z - h.z;
  const n = Math.hypot(dx, dy, dz);
  return n ? deg(Math.acos(Math.max(-1, Math.min(1, -dy / n)))) : null;
}

// view가 측면이면 화면 좌표로 정밀 측정, 아니면 3D 추정
function measure(F, s, lead, torso, view) {
  const A = F[s.adr], T = F[s.top], I = F[s.imp];
  const m = {};
  const side = view === 'side';
  const tA = side ? tilt(A) : tiltW(A), tI = side ? tilt(I) : tiltW(I);
  m.posture_tilt = tA;
  const kl = angle3(A.W[LHIP], A.W[LKN], A.W[LAN]), kr = angle3(A.W[RHIP], A.W[RKN], A.W[RAN]);
  m.knee_flex = kl != null && kr != null ? 180 - (kl + kr) / 2 : null;
  m.lead_arm = angle3(T.W[lead.sh], T.W[lead.el], T.W[lead.wr]);
  m.spine_maintain = tA != null && tI != null ? Math.abs(tI - tA) : null;

  const shW = Math.abs(A.L[LSH].x - A.L[RSH].x);
  const anW = Math.abs(A.L[LAN].x - A.L[RAN].x);
  m.stance_width = shW > 0 ? anW / shW : null;
  let sway = 0;
  for (let i = s.adr; i <= s.imp; i++) sway = Math.max(sway, Math.abs(F[i].L[NOSE].x - A.L[NOSE].x));
  m.head_sway = shW > 0 ? sway / shW : null;
  // 목표 방향: 어드레스 때 리드 어깨가 있는 쪽
  const dir = Math.sign(A.L[lead.sh].x - A.L[lead.tsh].x) || 1;
  m.weight_shift = anW > 0 ? ((I.hip.x - A.hip.x) * dir) / anW : null;
  m.head_height = Math.abs(I.L[NOSE].y - A.L[NOSE].y) / torso;

  // 피니시 0.6초간 골반 중심 흔들림(몸통 길이 단위 표준편차)
  const pts = [];
  for (let i = s.fin; i < F.length && F[i].t - F[s.fin].t <= 0.6; i++) pts.push(F[i].hip);
  if (pts.length >= 4) {
    const mx = pts.reduce((a, p) => a + p.x, 0) / pts.length;
    const my = pts.reduce((a, p) => a + p.y, 0) / pts.length;
    m.finish_balance = Math.sqrt(pts.reduce((a, p) => a + (p.x - mx) ** 2 + (p.y - my) ** 2, 0) / pts.length) / torso;
  } else m.finish_balance = null;
  m.tempo = s.tempo;
  return m;
}
