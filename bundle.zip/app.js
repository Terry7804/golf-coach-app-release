// 골프 코치 화면 흐름: 영상 → 관절 수집 → 분석 → 코칭 → 기록/비교
import {
  FilesetResolver,
  PoseLandmarker,
  DrawingUtils,
} from './vendor/tasks-vision/vision_bundle.js';
import { markReady, checkForUpdate, currentBuild } from './updater.js';
import { analyze, summarize } from './analysis.js';
import { loadPalm, makeSignal } from './signal.js';
import { ISSUES, VIEW_NAME, fmt, pickFocus, compare, judge } from './coach.js';
import { Capacitor, registerPlugin } from './vendor/capacitor-core.js';
import { loadSessions, saveSession, deleteSession, shareCSV } from './storage.js';
import {
  FIELDS, CLUBS, SPEED_UNITS, DIST_UNITS, readPhoto, parseScreen, interpret, fmtField,
  loadShots, saveShot, deleteShot, relatedToday,
} from './shot.js';

const APP_VERSION = '3.1';

// 여기까지 왔다면 새 화면 파일이 정상적으로 불러와진 것
markReady();
checkForUpdate(document.getElementById('update'));
currentBuild().then((b) => {
  document.getElementById('ver').textContent = `v${APP_VERSION}` + (b ? ` · 빌드 ${b}` : '');
});

const $ = (id) => document.getElementById(id);
const video = $('video'), canvas = $('overlay'), ctx = canvas.getContext('2d');
const draw = new DrawingUtils(ctx);
let landmarker = null, engine = '', lastTs = 0, busy = false;
let liveLandmarker = null, liveModel = ''; // 실시간 연습용 가벼운(lite) 모델
let handed = localStorage.getItem('golf.handed') || 'right';
let current = null; // 마지막 분석 결과 (기록 전)
let practice = localStorage.getItem('golf.practice') || null; // 집중 연습 중인 항목 코드
if (practice && !ISSUES[practice]) practice = null;

// ---------- 집중 연습 항목 ----------
function setPractice(code) {
  practice = code;
  if (code) localStorage.setItem('golf.practice', code); else localStorage.removeItem('golf.practice');
  renderPractice();
}
function renderPractice() {
  const el = $('practice');
  if (!practice) { el.hidden = true; return; }
  const d = ISSUES[practice];
  el.hidden = false;
  el.innerHTML = `<span>🎯 연습 중: <b>${d.name}</b> (정상 ${rangeText(practice)})<br><small>${d.views.map((v) => VIEW_NAME[v]).join('·')} 촬영에서 측정돼요</small></span>`;
  const v = document.createElement('button');
  v.textContent = '▶ 영상';
  v.addEventListener('click', () => { location.href = videoUrl(practice); });
  el.appendChild(v);
  const b = document.createElement('button');
  b.textContent = '해제';
  b.addEventListener('click', () => setPractice(null));
  el.appendChild(b);
}

// 항목별 교본 영상 검색어. 사용자가 고른 고경민 프로 영상이 먼저 나오게 이름을 붙인다.
// (나중에 특정 영상 주소·장면으로 바꿀 수 있음)
const VIDEO_PRO = '고경민 프로';
const VIDEO_QUERY = {
  posture_tilt: '골프 어드레스 상체 숙임 각도 연습',
  knee_flex: '골프 어드레스 무릎 굽힘 연습',
  stance_width: '골프 스탠스 너비 맞추기',
  finish_balance: '골프 피니시 균형 연습',
  weight_shift: '골프 체중 이동 연습 드릴',
  head_sway: '골프 스윙 머리 고정 스웨이 교정',
  head_height: '골프 스윙 머리 높이 유지 연습',
  lead_arm: '골프 백스윙 왼팔 펴기 연습',
  tempo: '골프 스윙 템포 리듬 연습',
  spine_maintain: '골프 척추각 유지 얼리익스텐션 교정',
};
function videoUrl(code) {
  const q = (VIDEO_QUERY[code] || '골프 ' + ISSUES[code].name + ' 연습').replace(/^골프 /, '');
  return 'https://www.youtube.com/results?search_query=' + encodeURIComponent(`${VIDEO_PRO} ${q}`);
}

// ---------- 음성 ----------
const TTS = Capacitor.isNativePlatform() ? registerPlugin('TextToSpeech') : null;
function speak(text) {
  (async () => {
    try {
      if (TTS) { await TTS.stop().catch(() => {}); await TTS.speak({ text, lang: 'ko-KR', rate: 1.0, pitch: 1.0, volume: 1.0 }); return; }
    } catch (e) { console.warn('TTS 실패', e); }
    try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.lang = 'ko-KR'; speechSynthesis.speak(u); } catch { /* 음성 없음 */ }
  })();
}
function sayVal(code, v) {
  const u = ISSUES[code].unit;
  if (u === '°') return `${Math.round(v)}도`;
  if (u === ':1') return `${v.toFixed(1)} 대 1`;
  return v.toFixed(2);
}
function sayRange(code) {
  const [a, b] = ISSUES[code].range;
  if (code === 'finish_balance') return `${b} 이하`;
  return `${sayVal(code, a)}에서 ${sayVal(code, b)}`;
}
// 스윙 하나에 대한 한 문장 코칭
function coachLine(n, m, view) {
  const codes = Object.keys(ISSUES).filter((c) => (ISSUES[c].views.includes(view) || ISSUES[c].est3d) && m[c] != null && isFinite(m[c]));
  if (practice) {
    const d = ISSUES[practice];
    if (!codes.includes(practice)) return `${n}번째 스윙. ${d.name}, 이 각도에서는 측정이 안 돼요. ${d.views.map((v) => VIEW_NAME[v]).join(' 또는 ')}에서 찍어 주세요.`;
    const j = judge(practice, m[practice]);
    return `${n}번째 스윙. ${d.name}, ${sayVal(practice, m[practice])}. ` +
      (j.status === 'ok' ? '좋아요!' : `${j.status === 'low' ? '낮아요' : '높아요'}. 정상은 ${sayRange(practice)}.`);
  }
  const bad = codes.map((c) => ({ c, ...judge(c, m[c]) }))
    .filter((x) => x.status === 'low' || x.status === 'high')
    .sort((a, b) => ISSUES[a.c].group - ISSUES[b.c].group || b.dist - a.dist);
  if (!bad.length) return `${n}번째 스윙. 좋아요!`;
  const d = ISSUES[bad[0].c];
  return `${n}번째 스윙. ${bad[0].status === 'low' ? d.low : d.high}`;
}

// ---------- 탭 ----------
document.querySelectorAll('.tabs button').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
  for (const t of ['analyze', 'shot', 'history', 'help']) $('tab-' + t).hidden = t !== b.dataset.tab;
  if (b.dataset.tab === 'history') renderHistory();
}));

// ---------- 우타/좌타 ----------
function renderHanded() {
  document.querySelectorAll('#handed button').forEach((b) => b.classList.toggle('on', b.dataset.v === handed));
}
document.querySelectorAll('#handed button').forEach((b) => b.addEventListener('click', () => {
  handed = b.dataset.v; localStorage.setItem('golf.handed', handed); renderHanded();
}));
renderHanded();

function setStatus(text, isError = false) {
  $('status').textContent = text;
  $('status').classList.toggle('error', isError);
}

// ---------- 분석 엔진 ----------
// numPoses 2: 스크린골프 리플레이처럼 한 화면에 사람이 둘일 때 한 명만 따라가기 위해
async function createLandmarker(delegate, runningMode = 'VIDEO', model = 'full') {
  const vision = await FilesetResolver.forVisionTasks(new URL('./vendor/tasks-vision/wasm', location.href).href);
  return PoseLandmarker.createFromOptions(vision, {
    baseOptions: { modelAssetPath: new URL(`./models/pose_landmarker_${model}.task`, location.href).href, delegate },
    runningMode,
    numPoses: 2,
    // 화면을 다시 찍은 흐린 영상에서도 사람을 덜 놓치도록 기준을 낮춤 (기본 0.5)
    minPoseDetectionConfidence: 0.3,
    minPosePresenceConfidence: 0.3,
    minTrackingConfidence: 0.3,
  });
}

// ---------- 영상 방향(회전) ----------
let rot = 0, probe = null;
const MAX_SIDE = 960; // 분석용 화면 크기 상한 (속도)
function rotDims(r) {
  const w = video.videoWidth, h = video.videoHeight;
  return r % 180 ? [h, w] : [w, h];
}
// 지금 영상 화면을 r도 돌려서 캔버스 c에 그린다
function drawFrame(c, cx, r, maxSide) {
  const [w, h] = rotDims(r);
  const s = Math.min(1, maxSide / Math.max(w, h));
  const cw = Math.round(w * s), ch = Math.round(h * s);
  if (c.width !== cw || c.height !== ch) { c.width = cw; c.height = ch; }
  cx.save();
  cx.translate(cw / 2, ch / 2);
  cx.rotate((r * Math.PI) / 180);
  const vw = video.videoWidth * s, vh = video.videoHeight * s;
  cx.drawImage(video, -vw / 2, -vh / 2, vw, vh);
  cx.restore();
}
// 영상 몇 장면을 0/90/270/180도로 돌려 보며 사람이 똑바로 서 보이는 방향을 고른다
async function detectRotation() {
  if (!probe) probe = await createLandmarker(engine, 'IMAGE');
  const tmp = document.createElement('canvas'), tc = tmp.getContext('2d');
  const score = { 0: 0, 90: 0, 180: 0, 270: 0 };
  for (const p of [0.2, 0.45, 0.7]) {
    video.currentTime = (video.duration || 1) * p;
    await waitEvent(video, 'seeked');
    for (const r of [0, 90, 270, 180]) {
      drawFrame(tmp, tc, r, 640);
      const res = probe.detect(tmp);
      for (const lm of res.landmarks || []) {
        const sh = (lm[11].y + lm[12].y) / 2, hp = (lm[23].y + lm[24].y) / 2, an = (lm[27].y + lm[28].y) / 2;
        const vis = (lm[11].visibility + lm[12].visibility + lm[23].visibility + lm[24].visibility) / 4;
        if (sh < hp && hp < an) score[r] += 1 + vis;
      }
    }
  }
  let best = 0;
  for (const r of [90, 270, 180]) if (score[r] > score[best] + 0.01) best = r;
  return best;
}

// 사람이 둘 이상이면: 처음엔 가장 크게 보이는 사람, 그다음부턴 직전 골반 위치와 가장 가까운 사람
let prevHip = null, misses = 0;
function pickPose(list) {
  if (!list?.length) return -1;
  let best = -1, bv = Infinity;
  list.forEach((lm, i) => {
    const hx = (lm[23].x + lm[24].x) / 2, hy = (lm[23].y + lm[24].y) / 2;
    let val;
    if (prevHip) val = Math.hypot(hx - prevHip.x, hy - prevHip.y);
    else { const ys = lm.map((p) => p.y); val = -(Math.max(...ys) - Math.min(...ys)); }
    if (val < bv) { bv = val; best = i; }
  });
  if (prevHip && bv > 0.25) { if (++misses > 15) { prevHip = null; misses = 0; } return -1; }
  misses = 0;
  const lm = list[best];
  prevHip = { x: (lm[23].x + lm[24].x) / 2, y: (lm[23].y + lm[24].y) / 2 };
  return best;
}
// 실시간 연습은 매 프레임 처리해야 해서 가벼운 lite 모델을 쓴다(저장 영상 분석은 정밀한 full 모델).
// lite를 못 불러오면 full 모델로 대신한다.
async function getLiveLandmarker() {
  if (liveLandmarker) return liveLandmarker;
  for (const delegate of [engine || 'GPU', 'CPU']) {
    try { liveLandmarker = await createLandmarker(delegate, 'VIDEO', 'lite'); liveModel = '가벼운 모델'; return liveLandmarker; }
    catch (e) { console.warn('lite 모델 실패', delegate, e); }
  }
  liveModel = '정밀 모델';
  return landmarker;
}

// 화면 켜둠: 플러그인(새 APK 필요) → 안 되면 브라우저 기능(wakeLock)
const KeepAwake = Capacitor.isNativePlatform() ? registerPlugin('KeepAwake') : null;
async function keepScreenOn(on) {
  let ok = false;
  if (KeepAwake) {
    try { await (on ? KeepAwake.keepAwake() : KeepAwake.allowSleep()); ok = true; } catch (e) { console.warn('KeepAwake 실패', e); }
  }
  return ok;
}

async function init() {
  try { landmarker = await createLandmarker('GPU'); engine = 'GPU'; }
  catch (e) {
    console.warn('GPU 실패, CPU로 재시도', e);
    try { landmarker = await createLandmarker('CPU'); engine = 'CPU'; }
    catch (e2) { setStatus('분석 엔진을 불러오지 못했어요: ' + (e2?.message || e2), true); return; }
  }
  setStatus('준비 완료. 스윙 영상을 고르거나 바로 촬영해 주세요. (처음이면 "촬영 방법" 탭을 봐 주세요)');
}

// ---------- 영상 선택 ----------
for (const id of ['file', 'cam']) {
  $(id).addEventListener('change', (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (f) runAnalysis(f);
  });
}

function waitEvent(el, ev) { return new Promise((r) => el.addEventListener(ev, r, { once: true })); }

async function runAnalysis(file) {
  if (busy) return;
  if (!landmarker) { setStatus('분석 엔진이 아직 준비되지 않았어요. 잠시 후 다시 해 주세요.', true); return; }
  busy = true;
  $('result').hidden = true;
  current = null;
  if (video.src) URL.revokeObjectURL(video.src);
  video.src = URL.createObjectURL(file);
  $('stage').hidden = false;
  await waitEvent(video, 'loadedmetadata');

  setStatus('영상 방향을 확인하는 중…');
  try { rot = await detectRotation(); } catch (e) { console.warn('방향 확인 실패', e); rot = 0; }
  const rotNote = rot ? ` (영상이 누워 있어서 ${rot}° 돌려서 분석해요)` : '';
  prevHip = null; misses = 0;

  setStatus('관절을 찾는 중… 영상을 천천히 재생하며 분석해요.' + rotNote);
  const frames = await collectFrames();
  setStatus('스윙을 나누고 측정하는 중…');
  await new Promise((r) => setTimeout(r, 30));

  const res = analyze(frames, canvas.width, canvas.height, handed);
  busy = false;
  if (res.error) { setStatus(res.error, true); return; }
  const focus = pickFocus(res.summary);
  current = {
    id: Date.now().toString(36),
    date: new Date().toISOString(),
    handed,
    view: res.view.view,
    viewConf: res.view.conf,
    swings: res.swings.length,
    summary: res.summary,
    focus: focus?.code || null,
    practice,
  };
  setStatus(`분석 완료: 스윙 ${res.swings.length}개, 촬영 각도 ${VIEW_NAME[res.view.view]} (신뢰도 ${res.view.conf}).`);
  await renderResult(res, frames, focus);
}

// 영상을 0.5배속으로 재생하면서 프레임마다 관절 좌표 수집
function collectFrames() {
  return new Promise((resolve) => {
    const frames = [];
    const bar = $('progress').firstElementChild;
    video.currentTime = 0;
    video.playbackRate = 0.5;
    const done = () => { video.pause(); video.playbackRate = 1; bar.style.width = '100%'; resolve(frames); };
    const onFrame = (now, meta) => {
      if (video.ended) return done();
      const t = meta?.mediaTime ?? video.currentTime;
      let ts = performance.now(); if (ts <= lastTs) ts = lastTs + 1; lastTs = ts;
      drawFrame(canvas, ctx, rot, MAX_SIDE);
      const r = landmarker.detectForVideo(canvas, ts);
      const k = pickPose(r.landmarks);
      const lm = k >= 0 ? r.landmarks[k] : null, wl = k >= 0 ? r.worldLandmarks?.[k] : null;
      if (lm && wl) {
        frames.push({ t, lm: lm.map(({ x, y, z, visibility }) => ({ x, y, z, visibility })), wl: wl.map(({ x, y, z }) => ({ x, y, z })) });
        drawPose(lm);
      }
      bar.style.width = (100 * video.currentTime / (video.duration || 1)).toFixed(1) + '%';
      next();
    };
    const next = () => ('requestVideoFrameCallback' in video ? video.requestVideoFrameCallback(onFrame) : requestAnimationFrame(() => onFrame()));
    video.addEventListener('ended', done, { once: true });
    next();
    video.play().catch((e) => { setStatus('영상을 재생하지 못했어요: ' + e.message, true); resolve(frames); });
  });
}

function drawPose(lm, c = ctx, d = draw, w = canvas.width) {
  const lw = Math.max(2, w / 200);
  d.drawConnectors(lm, PoseLandmarker.POSE_CONNECTIONS, { color: '#7CFC00', lineWidth: lw });
  d.drawLandmarks(lm, { color: '#FF5252', radius: lw * 1.1 });
}

// ---------- 결과 화면 ----------
async function renderResult(res, frames, focus) {
  $('result').hidden = false;

  // 오늘 고칠 1가지 (집중 연습 항목이 있으면 그 항목)
  const fEl = $('focus');
  fEl.className = 'card focus';
  $('detail').hidden = true;
  const ps = practice ? res.summary[practice] : null;
  if (practice) {
    const d = ISSUES[practice];
    const label = !ps ? '' : ps.status === 'ok' ? '정상 범위 안이에요 👍' : ps.status === 'low' ? d.low : d.high;
    fEl.innerHTML = `<h2>🎯 집중 연습: ${d.name}</h2>` + (ps
      ? `<div class="big">${label}</div><p>내 값 <b>${fmt(practice, ps.value)}</b> → 정상 범위 <b>${rangeText(practice)}</b> · 스윙 ${Math.round(ps.repeat * 100)}%에서 벗어남</p>`
      : `<p>이 촬영 각도에서는 측정되지 않아요. ${d.views.map((v) => VIEW_NAME[v]).join('·')}에서 찍어 주세요.</p>`) +
      `<div class="drill"><b>연습 방법</b><br>${d.drill}</div>`;
  } else if (!focus) {
    fEl.innerHTML = `<h2>오늘의 코칭</h2><div class="big">측정한 항목이 모두 기준 범위 안이에요 👍</div>
      <p>다른 각도(${res.view.view === 'side' ? '정면' : '측면'})에서도 찍어서 나머지 항목을 확인해 보세요.</p>`;
  } else {
    const d = ISSUES[focus.code];
    fEl.innerHTML = `<h2>오늘 고칠 것 1가지</h2>
      <div class="big">${d.name}: ${focus.status === 'low' ? d.low : d.high}</div>
      <p>내 값 <b>${fmt(focus.code, focus.value)}</b> → 정상 범위 <b>${rangeText(focus.code)}</b> · 스윙 ${Math.round(focus.repeat * 100)}%에서 발견</p>
      <p>${d.why}</p>
      <div class="drill"><b>연습 방법</b><br>${d.drill}</div>
      <p class="small">연습 후 같은 각도로 다시 찍으면 지난 기록과 비교해 드려요.</p>`;
  }

  // 항목표
  const rows = Object.keys(ISSUES).map((code) => {
    const s = res.summary[code], d = ISSUES[code];
    if (!s) return `<tr><td>${d.name}<span class="rng">${d.views.map((v) => VIEW_NAME[v]).join('·')}에서 측정</span></td><td class="v">-</td><td><span class="tag na">해당 없음</span></td></tr>`;
    const label = s.status === 'ok' ? '적정' : s.status === 'low' ? '낮음' : '높음';
    return `<tr class="${s.status}" data-code="${code}"><td>${d.name}${s.est ? '<span class="rng">3D 추정 · 정밀: ' + d.views.map((v) => VIEW_NAME[v]).join('·') + ' 촬영</span>' : ''}</td><td class="v"><b>${fmt(code, s.value)}</b><span class="rng">정상 ${rangeText(code)}</span></td><td><span class="tag ${s.status}">${label}</span></td></tr>`;
  });
  $('metrics').innerHTML = rows.join('');
  // 항목을 누르면 설명 + "이 항목 연습하기"
  $('metrics').querySelectorAll('tr[data-code]').forEach((tr) => tr.addEventListener('click', () => {
    const code = tr.dataset.code, d = ISSUES[code], s = res.summary[code];
    const el = $('detail');
    el.hidden = false;
    el.innerHTML = `<h2>${d.name}</h2>
      <p>내 값 <b>${fmt(code, s.value)}</b> → 정상 범위 <b>${rangeText(code)}</b>
      ${s.status === 'ok' ? ' (정상)' : ' · ' + (s.status === 'low' ? d.low : d.high)}</p>
      <p>${d.why}</p><div class="drill"><b>연습 방법</b><br>${d.drill}</div>`;
    // 교본 영상: 유튜브에서 이 항목 연습 영상 검색 결과를 연다 (외부 앱/브라우저)
    const yt = document.createElement('button');
    yt.className = 'btn';
    yt.style.background = '#c62828';
    yt.textContent = '▶ 교본 영상 보기 (유튜브)';
    yt.addEventListener('click', () => { location.href = videoUrl(code); });
    el.appendChild(yt);
    const b = document.createElement('button');
    b.className = 'btn';
    b.textContent = practice === code ? '연습 중인 항목이에요 (해제하기)' : '🎯 이 항목 연습하기';
    b.addEventListener('click', () => {
      setPractice(practice === code ? null : code);
      b.textContent = practice === code ? '연습 중인 항목이에요 (해제하기)' : '🎯 이 항목 연습하기';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    el.appendChild(b);
    el.scrollIntoView({ behavior: 'smooth' });
  }));

  // 재확인: 같은 타석의 가장 최근 기록과 비교
  const prev = loadSessions().find((s) => s.handed === current.handed);
  const cEl = $('compare');
  if (prev) {
    const cmp = compare(prev, current);
    const vText = { better: '좋아짐', worse: '나빠짐', same: '변화 없음' };
    const prevFocus = prev.focus ? cmp.rows.find((r) => r.code === prev.focus) : null;
    cEl.hidden = false;
    cEl.innerHTML = `<h2>지난 기록과 비교</h2>
      <p class="small">${new Date(prev.date).toLocaleString('ko-KR')} · ${VIEW_NAME[prev.view]} · 스윙 ${prev.swings}개</p>
      ${cmp.warnings.map((w) => `<p class="warn">⚠ ${w}</p>`).join('')}
      ${prevFocus ? `<p><b>지난번 고칠 것(${ISSUES[prevFocus.code].name})</b>: <span class="tag ${prevFocus.verdict}">${vText[prevFocus.verdict]}</span></p>` : ''}
      <table class="metrics">${cmp.rows.map((r) => `<tr><td>${ISSUES[r.code].name}</td><td class="v">${fmt(r.code, r.before)} → ${fmt(r.code, r.after)}</td><td><span class="tag ${r.verdict}">${vText[r.verdict]}</span></td></tr>`).join('') || '<tr><td>같이 비교할 항목이 없어요 (촬영 각도가 달라요).</td></tr>'}</table>`;
  } else cEl.hidden = true;

  $('swinginfo').textContent = `찾은 스윙 ${res.swings.length}개 중 첫 스윙 · 템포 ${res.swings[0].tempo.toFixed(1)} : 1` +
    (res.swings[0].fallback ? ' · 다운스윙 일부를 놓쳐서 대략 추정한 결과예요(템포는 부정확할 수 있어요)' : '') +
    ` · 관절 찾은 화면 ${frames.length}개`;
  await renderPhases(res.swings[0], frames);
  $('result').scrollIntoView({ behavior: 'smooth' });
}

function rangeText(code) {
  const d = ISSUES[code];
  const [a, b] = d.range;
  if (code === 'finish_balance') return `${b} 이하`;
  return `${fmt(code, a)} ~ ${fmt(code, b)}`;
}

// 어드레스/탑/임팩트/피니시 정지 화면 + 관절
// ---------- 스윙 순간 크게 보기 ----------
// 어드레스·탑·임팩트·피니시 사진을 크게 보고, ◀ ▶로 한 장씩 넘겨 정확한 순간을 찾는다.
const PHASES = [['adr', '어드레스'], ['top', '탑'], ['imp', '임팩트'], ['fin', '피니시']];
let phaseView = null; // { swing, frames, rot }
const viewer = { key: 'adr', i: 0, pose: true, zoom: false, token: 0 };

function openViewer(key) {
  if (!phaseView || live) return;
  viewer.key = key; viewer.i = phaseView.swing[key];
  $('viewer').hidden = false;
  document.body.classList.add('noscroll');
  renderViewer();
}
function closeViewer() {
  $('viewer').hidden = true;
  document.body.classList.remove('noscroll');
}

async function renderViewer() {
  const { swing, frames, rot: r } = phaseView;
  viewer.i = Math.max(0, Math.min(frames.length - 1, viewer.i));
  const f = frames[viewer.i];
  const my = ++viewer.token;
  video.currentTime = f.t;
  await waitEvent(video, 'seeked');
  if (my !== viewer.token) return; // 버튼을 빨리 누르면 마지막 것만 그림
  const c = $('vCanvas'), cx = c.getContext('2d');
  drawFrame(c, cx, r, 1280);
  if (viewer.pose) drawPose(f.lm, cx, new DrawingUtils(cx), c.width);
  // 지금 장면이 어느 순간에서 몇 장 떨어졌는지
  const label = PHASES.find(([k]) => k === viewer.key)[1];
  const off = viewer.i - swing[viewer.key];
  $('vTitle').textContent = label + (off ? ` ${off > 0 ? '+' : ''}${off}장` : '');
  $('vInfo').textContent = `영상 ${f.t.toFixed(2)}초 · ◀ ▶로 한 장씩 넘겨 정확한 순간을 찾아보세요. 사진을 두 번 누르면 확대돼요.`;
  document.querySelectorAll('#vTabs button').forEach((b) => b.classList.toggle('on', b.dataset.k === viewer.key));
  $('vPose').textContent = viewer.pose ? '관절 끄기' : '관절 보기';
  $('vZoom').textContent = viewer.zoom ? '원래 크기' : '확대';
}

function setZoom(on, ev) {
  viewer.zoom = on;
  const sc = $('vScroll'), c = $('vCanvas');
  // 누른 곳을 기준으로 확대
  const rect = c.getBoundingClientRect();
  const fx = ev ? (ev.clientX - rect.left) / rect.width : 0.5, fy = ev ? (ev.clientY - rect.top) / rect.height : 0.5;
  sc.classList.toggle('zoom', on);
  if (on) {
    sc.scrollLeft = c.offsetWidth * fx - sc.clientWidth / 2;
    sc.scrollTop = c.offsetHeight * fy - sc.clientHeight / 2;
  }
  $('vZoom').textContent = on ? '원래 크기' : '확대';
}

$('vClose').addEventListener('click', closeViewer);
$('vPrev').addEventListener('click', () => { viewer.i--; renderViewer(); });
$('vNext').addEventListener('click', () => { viewer.i++; renderViewer(); });
$('vPose').addEventListener('click', () => { viewer.pose = !viewer.pose; renderViewer(); });
$('vZoom').addEventListener('click', () => setZoom(!viewer.zoom));
$('vCanvas').addEventListener('dblclick', (e) => setZoom(!viewer.zoom, e));
document.querySelectorAll('#vTabs button').forEach((b) => b.addEventListener('click', () => {
  viewer.key = b.dataset.k; viewer.i = phaseView.swing[b.dataset.k]; renderViewer();
}));
// 옆으로 밀어서 한 장씩 넘기기 (확대 중에는 사진 이동이 우선)
{
  let sx = null;
  $('vScroll').addEventListener('touchstart', (e) => { sx = viewer.zoom ? null : e.touches[0].clientX; }, { passive: true });
  $('vScroll').addEventListener('touchend', (e) => {
    if (sx == null) return;
    const dx = e.changedTouches[0].clientX - sx; sx = null;
    if (Math.abs(dx) > 50) { viewer.i += dx < 0 ? 1 : -1; renderViewer(); }
  });
}

async function renderPhases(swing, frames) {
  const box = $('phases');
  box.innerHTML = '';
  const names = [['adr', '어드레스'], ['top', '탑'], ['imp', '임팩트'], ['fin', '피니시']];
  for (const [key, label] of names) {
    const f = frames[swing[key]];
    video.currentTime = f.t;
    await waitEvent(video, 'seeked');
    const c = document.createElement('canvas');
    const cx = c.getContext('2d');
    drawFrame(c, cx, rot, 240);
    drawPose(f.lm, cx, new DrawingUtils(cx), c.width);
    const fig = document.createElement('figure');
    fig.appendChild(c);
    fig.insertAdjacentHTML('beforeend', `<figcaption>${label} 🔍</figcaption>`);
    fig.addEventListener('click', () => openViewer(key));
    box.appendChild(fig);
  }
  phaseView = { swing, frames, rot };
  video.currentTime = frames[swing.adr].t;
  await waitEvent(video, 'seeked');
  drawFrame(canvas, ctx, rot, MAX_SIDE);
  drawPose(frames[swing.adr].lm);
}

// ---------- 기록 ----------
$('save').addEventListener('click', () => {
  if (!current) return;
  current.memo = $('memo').value.trim();
  saveSession(current);
  current = null;
  $('save').textContent = '기록했어요 ✓';
  setTimeout(() => { $('save').textContent = '이 결과 기록하기'; }, 2000);
});

function renderHistory() {
  const list = loadSessions();
  const shots = loadShots();
  const el = $('history');
  if (!list.length && !shots.length) { el.innerHTML = '<div class="hist">아직 기록이 없어요. 스윙을 분석한 뒤 "이 결과 기록하기"를 눌러 주세요.</div>'; return; }
  const items = [
    ...list.map((s) => ({ date: s.date, html: sessionHtml(s) })),
    ...shots.map((s) => ({ date: s.date, html: shotHtml(s) })),
  ].sort((a, b) => new Date(b.date) - new Date(a.date));
  el.innerHTML = items.map((x) => x.html).join('');
  el.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => {
    if (confirm('이 기록을 삭제할까요?')) { deleteSession(b.dataset.del); renderHistory(); }
  }));
  el.querySelectorAll('[data-delshot]').forEach((b) => b.addEventListener('click', () => {
    if (confirm('이 기록을 삭제할까요?')) { deleteShot(b.dataset.delshot); renderHistory(); }
  }));
}

function shotHtml(s) {
  const vals = Object.entries(s.values).filter(([, v]) => v != null)
    .map(([c, v]) => `${FIELDS[c].name} ${fmtField(c, v, s.units)}`).join(' · ');
  return `<div class="hist">
      <div class="top"><span class="when">📷 ${new Date(s.date).toLocaleString('ko-KR')}</span>
        <button class="btn ghost" data-delshot="${s.id}">삭제</button></div>
      <div class="meta">연습장 화면 · ${CLUBS[s.club]?.name || ''}${s.memo ? ' · ' + escapeHtml(s.memo) : ''}<br>${vals || '수치 없음'}</div>
    </div>`;
}

function sessionHtml(s) {
  const bad = Object.entries(s.summary).filter(([, m]) => m.status === 'low' || m.status === 'high').map(([c]) => ISSUES[c].name);
  return `<div class="hist">
    <div class="top"><span class="when">${new Date(s.date).toLocaleString('ko-KR')}</span>
      <button class="btn ghost" data-del="${s.id}">삭제</button></div>
    <div class="meta">${VIEW_NAME[s.view]} · ${s.handed === 'left' ? '좌타' : '우타'} · 스윙 ${s.swings}개${s.memo ? ' · ' + escapeHtml(s.memo) : ''}<br>
      고칠 것: <b>${s.focus ? ISSUES[s.focus].name : '없음'}</b>${bad.length ? ' · 벗어난 항목: ' + bad.join(', ') : ''}</div>
  </div>`;
}

$('export').addEventListener('click', async () => {
  const list = loadSessions();
  const shots = loadShots();
  if (!list.length && !shots.length) { alert('내보낼 기록이 없어요.'); return; }
  try { await shareCSV(list, shots); } catch (e) { alert('내보내기 실패: ' + (e?.message || e)); }
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------- 연습장 결과 화면 사진 ----------
// 사진 → 폰 안 글자 인식 → 이름 옆 숫자 찾기 → 해석. 읽은 값은 사용자가 고칠 수 있다.
let shot = null; // { values, units, raw, preview }
let shotClub = localStorage.getItem('golf.shotClub') || 'iron';

function renderShotClub() {
  document.querySelectorAll('#shotClub button').forEach((b) => b.classList.toggle('on', b.dataset.v === shotClub));
}
document.querySelectorAll('#shotClub button').forEach((b) => b.addEventListener('click', () => {
  shotClub = b.dataset.v; localStorage.setItem('golf.shotClub', shotClub); renderShotClub();
  if (shot) renderShotNotes();
}));
renderShotClub();
$('shotSpeedUnit').innerHTML = SPEED_UNITS.map((u) => `<option>${u}</option>`).join('');
$('shotDistUnit').innerHTML = DIST_UNITS.map((u) => `<option>${u}</option>`).join('');

for (const id of ['shotFile', 'shotCam']) {
  $(id).addEventListener('change', async (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (f) await runShot(f);
  });
}

function shotStatus(text, isError = false) {
  const el = $('shotStatus');
  el.hidden = !text;
  el.textContent = text || '';
  el.classList.toggle('error', isError);
}

async function runShot(file) {
  $('shotResult').hidden = true;
  shotStatus('사진에서 글자를 읽는 중…');
  try {
    const ocr = await readPhoto(file);
    const parsed = parseScreen(ocr);
    shot = { ...parsed, preview: ocr.preview };
    const n = Object.keys(parsed.values).length;
    shotStatus(n ? `수치 ${n}개를 읽었어요. 사진과 비교해서 틀린 값은 고쳐 주세요.`
      : '수치를 찾지 못했어요. 화면을 더 크게, 정면에서 다시 찍거나 아래 칸에 직접 넣어 주세요.', !n);
  } catch (e) {
    shot = { values: {}, units: { speed: 'm/s', dist: 'm' }, raw: '', preview: null };
    shotStatus('글자를 읽지 못했어요: ' + (e?.message || e) + '\n아래 칸에 직접 넣어도 해석해 드려요.', true);
  }
  renderShot();
}

function renderShot() {
  $('shotResult').hidden = false;
  $('shotImgBox').hidden = !shot.preview;
  if (shot.preview) $('shotImg').src = shot.preview;
  $('shotSpeedUnit').value = shot.units.speed;
  $('shotDistUnit').value = shot.units.dist;
  $('shotFields').innerHTML = Object.entries(FIELDS).map(([code, f]) => {
    const v = shot.values[code];
    const unit = f.unit === 'speed' ? shot.units.speed : f.unit === 'dist' ? shot.units.dist : f.unit;
    return `<label>${f.name}${unit ? ' (' + unit + ')' : ''}
      <input type="number" inputmode="decimal" step="any" data-field="${code}" value="${v ?? ''}" class="${v != null ? 'got' : ''}"></label>`;
  }).join('');
  $('shotRaw').textContent = shot.raw || '(읽은 글자 없음)';
  renderShotNotes();
}

function readShotInputs() {
  const values = {};
  $('shotFields').querySelectorAll('input[data-field]').forEach((i) => {
    const v = i.value.trim() === '' ? null : Number(i.value);
    if (v != null && isFinite(v)) values[i.dataset.field] = v;
  });
  shot.values = values;
  shot.units = { speed: $('shotSpeedUnit').value, dist: $('shotDistUnit').value };
}

function renderShotNotes() {
  const notes = interpret(shot.values, shotClub, handed);
  const rel = relatedToday(notes, loadSessions());
  const el = $('shotNotes');
  el.innerHTML = `<h2>해석 (${CLUBS[shotClub].name} 기준)</h2>
    <ul class="notes">${notes.map((n) => `<li class="${n.level}">${escapeHtml(n.text)}</li>`).join('')}</ul>
    ${rel.both.length ? `<p><b>오늘 영상 분석에서도 벗어난 자세:</b> ${rel.both.map((c) => ISSUES[c].name).join(', ')} → 이것부터 연습해 보세요.</p>` : ''}
    ${rel.related.length ? `<p class="small">관련 있을 수 있는 자세 항목 (누르면 그 항목을 연습해요):</p><div class="chips">${rel.related.map((c) => `<button data-practice="${c}">${ISSUES[c].name}</button>`).join('')}</div>` : ''}
    ${rel.related.length && !rel.hasToday ? '<p class="small">오늘 스윙 영상도 분석해서 기록하면, 자세 측정과 함께 연결해서 알려 드려요.</p>' : ''}
    <p class="small">목표 범위는 초안이에요(티칭프로 감수 전). 좌우 판단은 ${handed === 'left' ? '좌타' : '우타'} 기준이에요.</p>`;
  el.querySelectorAll('[data-practice]').forEach((b) => b.addEventListener('click', () => {
    setPractice(b.dataset.practice);
    document.querySelector('.tabs button[data-tab="analyze"]').click();
    window.scrollTo(0, 0);
  }));
}

for (const id of ['shotSpeedUnit', 'shotDistUnit']) $(id).addEventListener('change', () => { readShotInputs(); renderShot(); });
$('shotRedo').addEventListener('click', () => { readShotInputs(); renderShotNotes(); $('shotNotes').scrollIntoView({ behavior: 'smooth' }); });
$('shotSave').addEventListener('click', () => {
  if (!shot) return;
  readShotInputs();
  if (!Object.keys(shot.values).length) { alert('저장할 수치가 없어요.'); return; }
  saveShot({
    id: 'shot-' + Date.now(), date: new Date().toISOString(), club: shotClub, handed,
    values: shot.values, units: shot.units, memo: $('shotMemo').value.trim(),
    notes: interpret(shot.values, shotClub, handed).map((n) => n.text),
  });
  $('shotSave').textContent = '기록했어요 ✓';
  setTimeout(() => { $('shotSave').textContent = '이 결과 기록하기'; }, 2000);
});

// ---------- 실시간 연습 (카메라 + 음성 코칭) ----------
// 폰을 세워 두고 시작만 누르면, 스윙이 끝날 때마다 그 스윙을 측정해 한 문장으로 말해 준다.
let live = null;

$('liveStart').addEventListener('click', startLive);

// 카메라 열기. 안드로이드 앱 화면(웹뷰)은 "전면" 요청을 무시하고 후면을 여는 경우가 있어서
// 1) 정확히 전면/후면 요청 → 2) 카메라 목록에서 이름(front/back)으로 골라 열기 → 3) 일반 요청 순으로 시도한다.
const CAM_SIZE = { width: { ideal: 1280 }, height: { ideal: 720 } };
const CAM_RE = { front: /front|user|selfie|전면|앞/i, back: /back|rear|environment|후면|뒤/i };
function camSide(stream) {
  const tr = stream.getVideoTracks()[0];
  const fm = tr?.getSettings?.().facingMode;
  if (fm === 'user') return 'front';
  if (fm === 'environment') return 'back';
  const label = tr?.label || '';
  if (CAM_RE.front.test(label)) return 'front';
  if (CAM_RE.back.test(label)) return 'back';
  return null;
}
async function openCamera(which) {
  const want = which === 'front' ? 'user' : 'environment';
  const stop = (st) => st?.getTracks().forEach((t) => t.stop());
  // 1) 정확히 요청
  try {
    const st = await navigator.mediaDevices.getUserMedia({ video: { ...CAM_SIZE, facingMode: { exact: want } }, audio: false });
    if (camSide(st) !== (which === 'front' ? 'back' : 'front')) return st;
    stop(st);
  } catch (e) { console.warn('facingMode exact 실패', e); }
  // 2) 카메라 목록에서 고르기 (이름은 권한을 받은 뒤에만 보여서, 필요하면 잠깐 열었다 닫는다)
  try {
    let devs = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
    if (devs.length && !devs.some((d) => d.label)) {
      stop(await navigator.mediaDevices.getUserMedia({ video: true, audio: false }));
      devs = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === 'videoinput');
    }
    let dev = devs.find((d) => CAM_RE[which].test(d.label));
    // 이름으로 못 찾으면: 보통 첫 번째가 후면, 마지막이 전면
    if (!dev && devs.length > 1) dev = which === 'front' ? devs[devs.length - 1] : devs[0];
    if (dev) return await navigator.mediaDevices.getUserMedia({ video: { ...CAM_SIZE, deviceId: { exact: dev.deviceId } }, audio: false });
  } catch (e) { console.warn('카메라 목록으로 열기 실패', e); }
  // 3) 일반 요청
  return navigator.mediaDevices.getUserMedia({ video: { ...CAM_SIZE, facingMode: want }, audio: false });
}

// 스윙 시작·끝 방법: 손 신호(손바닥 보여 주기, 기본) / 자동 감지
let liveTrigger = localStorage.getItem('golf.liveTrigger') || 'palm';
function renderLiveTrigger() {
  document.querySelectorAll('#liveTrigger button').forEach((b) => b.classList.toggle('on', b.dataset.v === liveTrigger));
  $('liveLevelRow').hidden = liveTrigger !== 'auto';
}
document.querySelectorAll('#liveTrigger button').forEach((b) => b.addEventListener('click', () => {
  if (live) { setStatus('연습 중에는 바꿀 수 없어요. "연습 끝내기" 후 바꿔 주세요.', true); return; }
  liveTrigger = b.dataset.v; localStorage.setItem('golf.liveTrigger', liveTrigger); renderLiveTrigger();
}));
renderLiveTrigger();

// 짧은 신호음 (시작: 높은 음, 끝: 낮은 음)
let audioCtx = null;
function beep(freq = 880, ms = 150) {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), gn = audioCtx.createGain();
    o.frequency.value = freq; gn.gain.value = 0.3;
    o.connect(gn); gn.connect(audioCtx.destination);
    o.start(); o.stop(audioCtx.currentTime + ms / 1000);
  } catch { /* 소리 안 나도 됨 */ }
}

// 스윙 인식 기준: 정확(어드레스 멈춤까지 확인) / 보통(숙이기·걷기·한 팔·팔 흔들기만 거름, 기본) / 느슨(예전 방식)
let liveStrict = localStorage.getItem('golf.liveLevel') || 'normal';
function renderLiveStrict() {
  document.querySelectorAll('#liveStrict button').forEach((b) => b.classList.toggle('on', b.dataset.v === liveStrict));
}
document.querySelectorAll('#liveStrict button').forEach((b) => b.addEventListener('click', () => {
  liveStrict = b.dataset.v; localStorage.setItem('golf.liveLevel', liveStrict); renderLiveStrict();
}));
renderLiveStrict();

// 실시간 연습 카메라: 후면(기본) / 전면(화면을 보면서 연습)
let liveCam = localStorage.getItem('golf.liveCam') || 'back';
function renderLiveCam() {
  document.querySelectorAll('#liveCam button').forEach((b) => b.classList.toggle('on', b.dataset.v === liveCam));
}
document.querySelectorAll('#liveCam button').forEach((b) => b.addEventListener('click', async () => {
  if (b.dataset.v === liveCam && !live) return;
  liveCam = b.dataset.v; localStorage.setItem('golf.liveCam', liveCam); renderLiveCam();
  if (live) await switchLiveCamera();
}));

function nextFrame(fn) {
  video.requestVideoFrameCallback ? video.requestVideoFrameCallback(fn) : requestAnimationFrame(fn);
}

// 연습 중에 카메라 바꾸기: 새 카메라를 열고 영상만 갈아 끼운다(스윙 기록은 유지)
async function switchLiveCamera() {
  const L = live;
  let st;
  try { st = await openCamera(liveCam); } catch (e) { setStatus('카메라를 바꾸지 못했어요: ' + (e?.message || e), true); return; }
  if (live !== L) { st.getTracks().forEach((t) => t.stop()); return; }
  L.stream.getTracks().forEach((t) => t.stop());
  L.stream = st;
  L.buf = []; // 다른 카메라 화면과 섞이지 않게 비움
  video.srcObject = st;
  await video.play().catch(() => {});
  L.gen++;
  const g = L.gen;
  nextFrame(() => L.loop(g));
  $('stage').classList.toggle('mirror', liveCam === 'front');
  $('liveLast').textContent = `${liveCam === 'front' ? '전면' : '후면'} 카메라로 바꿨어요.` + (camSide(st) && camSide(st) !== liveCam ? ' (폰이 다른 카메라를 열었어요)' : '');
}
renderLiveCam();
$('liveStop').addEventListener('click', () => stopLive());

async function startLive() {
  if (live || busy) return;
  if (!landmarker) { setStatus('분석 엔진이 아직 준비되지 않았어요. 잠시 후 다시 해 주세요.', true); return; }
  setStatus('실시간 분석 엔진을 준비하는 중…');
  const lm = await getLiveLandmarker();
  let palmOk = true;
  if (liveTrigger === 'palm') {
    setStatus('손 신호 인식 엔진을 준비하는 중…');
    try { await loadPalm(engine || 'GPU'); } catch (e) { console.warn('손바닥 인식 실패', e); palmOk = false; }
  }
  let stream;
  try {
    stream = await openCamera(liveCam);
  } catch (e) {
    setStatus('카메라를 켜지 못했어요. 카메라 권한을 허용해 주세요. (' + (e?.message || e) + ')', true);
    return;
  }
  $('result').hidden = true;
  if (video.src) { URL.revokeObjectURL(video.src); video.removeAttribute('src'); }
  video.srcObject = stream;
  await video.play().catch(() => {});
  rot = 0; prevHip = null; misses = 0;
  live = { stream, lm, buf: [], swings: [], lastImpT: -1, n: 0, lastCheck: 0, lastSwingAt: performance.now(), wake: null,
    whys: [], sig: liveTrigger === 'palm' ? makeSignal() : null, rec: null, recStart: 0, frames: 0, fpsT: performance.now(), fps: 0, slowWarned: false, keep: false };
  live.keep = await keepScreenOn(true);
  if (!live.keep) { try { live.wake = await navigator.wakeLock?.request('screen'); } catch { /* 화면 켜둠 미지원 */ } }
  $('stage').hidden = false;
  // 전면 카메라는 거울처럼 보이게 화면만 뒤집는다(분석은 원래 영상 그대로)
  $('stage').classList.toggle('mirror', liveCam === 'front');
  $('liveWhy').textContent = '';
  $('liveBox').hidden = false;
  $('liveStart').hidden = true;
  $('liveCount').textContent = '스윙 0개';
  $('liveLast').textContent = live.sig
    ? '손바닥을 카메라에 보여 주면 시작, 스윙 후 다시 보여 주면 끝이에요.'
    : '몸 전체가 화면에 보이게 서서, 어드레스에서 잠깐 멈췄다가 스윙하세요.';
  setLiveState();
  setStatus('실시간 연습 중' + (practice ? ` · 집중 항목: ${ISSUES[practice].name}` : '') +
    `\n${liveModel} · ${live.keep || live.wake ? '화면 켜둠 켜짐' : '화면 켜둠이 안 돼요: 폰 설정에서 화면 꺼짐 시간을 늘려 주세요'}` +
    `\n카메라: ${{ front: '전면', back: '후면' }[camSide(stream)] || '확인 불가'} (고른 것: ${liveCam === 'front' ? '전면' : '후면'})` +
    ` · ${stream.getVideoTracks()[0]?.label || ''}`);
  speak(live.sig ? '연습을 시작합니다. 손바닥을 보여 주면 시작, 스윙이 끝나면 다시 손바닥을 보여 주세요.'
    : '연습을 시작합니다. 어드레스에서 잠깐 멈췄다가 스윙하세요.');
  if (live.sig && !palmOk) $('liveWhy').textContent = '손바닥 인식을 못 켰어요. 한 손을 머리 위로 들어도 신호로 알아들어요.';
  $('stage').scrollIntoView({ behavior: 'smooth' });

  // gen: 카메라를 바꾸면 늘어나서, 예전 카메라에 걸려 있던 반복은 멈추고 새 반복만 돈다
  live.gen = 0;
  const loop = (g) => {
    if (!live || g !== live.gen) return;
    drawFrame(canvas, ctx, 0, 720);
    let ts = performance.now(); if (ts <= lastTs) ts = lastTs + 1; lastTs = ts;
    const r = live.lm.detectForVideo(canvas, ts);
    const k = pickPose(r.landmarks);
    const t = ts / 1000;
    // 초당 처리 장수(속도) 측정: 너무 느리면 스윙을 놓칠 수 있다
    live.frames++;
    if (ts - live.fpsT >= 2000) {
      live.fps = live.frames * 1000 / (ts - live.fpsT); live.frames = 0; live.fpsT = ts;
      $('liveFps').textContent = `처리 속도 ${live.fps.toFixed(0)}장/초 · ${liveModel}`;
      live.windows = (live.windows || 0) + 1; // 첫 구간은 엔진 준비 시간이 섞여 있어 판단에서 뺀다
      if (live.windows >= 2 && live.fps < 12 && !live.slowWarned) {
        live.slowWarned = true;
      }
      if (live.slowWarned) $('liveFps').textContent += ' (느려요: 다른 앱을 닫으면 빨라질 수 있어요)';
    }
    if (k >= 0 && r.worldLandmarks?.[k]) {
      const lm = r.landmarks[k];
      live.buf.push({ t, lm: lm.map(({ x, y, z, visibility }) => ({ x, y, z, visibility })), wl: r.worldLandmarks[k].map(({ x, y, z }) => ({ x, y, z })) });
      drawPose(lm);
      if (live.sig) {
        if (live.rec) live.rec.push(live.buf[live.buf.length - 1]);
        if (live.sig(canvas, lm, t)) onHandSignal(t);
      }
    }
    if (live.rec && t - live.recStart > 25) finishRec(t, '25초가 지나서 자동으로 끝냈어요.');
    while (live.buf.length && live.buf[0].t < t - 12) live.buf.shift(); // 최근 12초만 보관
    if (!live.sig && t - live.lastCheck > 0.5) { live.lastCheck = t; checkLiveSwing(t); }
    if (live && performance.now() - live.lastSwingAt > 180000) { stopLive('3분 동안 스윙이 없어서 자동으로 끝냈어요.'); return; }
    if (live) nextFrame(() => loop(g));
  };
  live.loop = loop;
  nextFrame(() => loop(0));
}

// ---------- 손 신호 모드 ----------
function setLiveState() {
  const el = $('liveState');
  if (!live?.sig) { el.hidden = true; return; }
  el.hidden = false;
  el.className = 'livestate ' + (live.rec ? 'rec' : 'wait');
  el.textContent = live.rec ? '● 녹화 중 · 스윙 후 손바닥' : '대기 · 손바닥을 보여 주면 시작';
}

function onHandSignal(t) {
  live.lastSwingAt = performance.now();
  if (!live.rec) {
    live.rec = []; live.recStart = t;
    beep(988, 180);
    $('liveLast').textContent = '시작! 스윙하고, 끝나면 손바닥을 보여 주세요.';
    $('liveWhy').textContent = '';
    setLiveState();
  } else {
    finishRec(t);
  }
}

// 시작 신호~끝 신호 사이를 스윙 영상처럼 분석한다
function finishRec(t, note) {
  // 시작 신호 동작(손 내리기) 0.8초와 끝 신호 동작 0.7초는 스윙으로 잘못 잡히지 않게 뺀다
  const frames = live.rec.filter((f) => f.t > live.recStart + 0.8 && f.t < t - 0.7);
  live.rec = null;
  beep(587, 180);
  setLiveState();
  let res;
  try { res = analyze(frames, canvas.width, canvas.height, handed); } catch (e) { res = { error: String(e?.message || e) }; }
  if (res.error || !res.swings?.length) {
    const msg = '스윙을 찾지 못했어요. 몸 전체가 보이게 다시 해 주세요.';
    $('liveLast').textContent = (note ? note + ' ' : '') + msg;
    $('liveWhy').textContent = res.error ? res.error.split('\n').pop() : '';
    speak(msg);
    return;
  }
  // 신호 사이에 스윙이 여러 개 잡히면 가장 큰 스윙 하나만 센다
  const h = (s) => frames[s.top].lm[15].y - frames[s.imp].lm[15].y;
  let best = 0;
  res.swings.forEach((s, i) => { if (Math.abs(h(s)) > Math.abs(h(res.swings[best]))) best = i; });
  reportSwing(res.perSwing[best], res.view.view, note);
}

function reportSwing(m, view, note) {
  live.n++;
  live.lastSwingAt = performance.now();
  live.swings.push({ m, view });
  const line = coachLine(live.n, m, view);
  $('liveCount').textContent = `스윙 ${live.n}개 · ${VIEW_NAME[view]}`;
  $('liveLast').textContent = (note ? note + ' ' : '') + line;
  speak(line);
}

function checkLiveSwing(t) {
  if (live.buf.length < 15) return;
  let res;
  const why = [];
  // strict: 어드레스(멈춤)→탑→빠른 다운스윙→임팩트→피니시(멈춤)가 다 있어야 스윙으로 센다
  try { res = analyze(live.buf, canvas.width, canvas.height, handed, { noFallback: true, strict: liveStrict === 'loose' ? false : liveStrict, why }); } catch (e) { console.warn(e); return; }
  // 거른 이유를 최근 3개까지 보여준다(기준 조정용). 같은 동작은 여러 번 검사되므로 중복은 뺀다
  for (const w of why) if (!live.whys.includes(w)) live.whys.push(w);
  live.whys = live.whys.slice(-3);
  if (live.whys.length) $('liveWhy').innerHTML = '스윙으로 안 센 동작:<br>' + live.whys.map(escapeHtml).join('<br>');
  if (res.error) return;
  res.swings.forEach((s, i) => {
    const impT = live.buf[s.imp].t, finT = live.buf[s.fin].t;
    if (impT <= live.lastImpT + 1) return; // 이미 말한 스윙
    if (t - finT < 0.6) return; // 피니시가 끝날 때까지 기다림
    live.lastImpT = impT;
    $('liveWhy').textContent = ''; live.whys = [];
    reportSwing(res.perSwing[i], res.view.view);
  });
}

function stopLive(msg) {
  if (!live) return;
  const L = live;
  live = null;
  L.stream.getTracks().forEach((tr) => tr.stop());
  $('stage').classList.remove('mirror');
  video.srcObject = null;
  try { L.wake?.release(); } catch { /* 무시 */ }
  if (L.keep) keepScreenOn(false);
  $('liveBox').hidden = true;
  $('liveState').hidden = true;
  $('liveStart').hidden = false;
  if (!L.swings.length) {
    setStatus((msg ? msg + ' ' : '') + '연습을 끝냈어요. 찾은 스윙이 없어요.');
    speak('연습을 끝냈어요.');
    return;
  }
  // 가장 많이 나온 촬영 각도 기준으로 요약해 기록
  const cnt = {};
  for (const s of L.swings) cnt[s.view] = (cnt[s.view] || 0) + 1;
  const view = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0][0];
  const summary = summarize(L.swings.filter((s) => s.view === view).map((s) => s.m), view);
  const focus = pickFocus(summary);
  saveSession({
    id: Date.now().toString(36), date: new Date().toISOString(), handed, view, viewConf: '실시간',
    swings: L.swings.length, summary, focus: focus?.code || null, practice, memo: '실시간 연습',
  });
  setStatus((msg ? msg + ' ' : '') + `연습 끝: 스윙 ${L.swings.length}개를 기록했어요. "연습 기록" 탭에서 볼 수 있어요.` +
    (focus ? ` 다음에 고칠 것: ${ISSUES[focus.code].name}` : ''));
  speak(`연습을 끝냈어요. 스윙 ${L.swings.length}개를 기록했어요.`);
}

renderPractice();
init();
