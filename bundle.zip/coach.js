// 측정 항목 정의 + 코칭 문구.
// 기준 범위는 초안이며 티칭프로 감수가 필요하다.
// group: 기본기 순서 (0 어드레스 → 1 균형 → 2 머리 → 3 백스윙 → 4 임팩트)
// err: 측정 오차. 재확인 때 이 이내 변화는 "변화 없음"
// views: 정밀 측정이 되는 촬영 각도. est3d: 다른 각도에서도 3D 좌표로 "추정" 측정 가능
export const ISSUES = {
  posture_tilt: {
    name: '상체 숙임', unit: '°', views: ['side'], est3d: true, range: [28, 48], err: 3, group: 0, digits: 0,
    low: '상체가 너무 서 있어요.', high: '상체를 너무 많이 숙였어요.',
    why: '어드레스 자세가 스윙 궤도와 균형의 출발점이에요.',
    drill: '클럽을 등에 세로로 대고 머리·등·엉덩이가 닿게 한 채, 엉덩이를 뒤로 빼며 숙여 보세요. 거울 옆에서 10번 반복.',
  },
  knee_flex: {
    name: '무릎 굽힘', unit: '°', views: ['side'], est3d: true, range: [12, 35], err: 3, group: 0, digits: 0,
    low: '무릎이 너무 펴져 있어요.', high: '무릎을 너무 많이 굽혔어요.',
    why: '무릎이 적당히 굽어야 체중을 받치고 몸을 돌릴 수 있어요.',
    drill: '의자 끝에 살짝 걸터앉는 느낌으로 무릎을 풀고, 발 앞꿈치 쪽에 체중을 두는 연습을 10번.',
  },
  stance_width: {
    name: '스탠스 너비', unit: '배', views: ['front'], range: [0.85, 1.35], err: 0.05, group: 0, digits: 2,
    low: '발 간격이 너무 좁아요.', high: '발 간격이 너무 넓어요.',
    why: '발 간격이 맞아야 머리가 흔들리지 않고 균형이 잡혀요.',
    drill: '양발 안쪽 간격을 어깨너비 정도로 맞추고, 발 앞에 클럽 두 개를 놓아 표시한 뒤 연습하세요.',
  },
  finish_balance: {
    name: '피니시 균형', unit: '', views: ['side', 'front', 'diag'], range: [0, 0.05], err: 0.01, group: 1, digits: 3,
    low: '', high: '피니시에서 몸이 흔들려요.',
    why: '피니시가 흔들리면 스윙 중 체중 이동이나 리듬이 불안정하다는 신호예요.',
    drill: '스윙 후 피니시 자세로 3초간 멈춰 서 있기. 70% 힘으로 10번, 버티면 힘을 조금씩 올리세요.',
  },
  weight_shift: {
    name: '체중 이동', unit: '', views: ['front'], range: [0.05, 0.35], err: 0.05, group: 1, digits: 2,
    low: '임팩트 때 체중이 목표 쪽으로 덜 옮겨졌어요.', high: '임팩트 때 골반이 목표 쪽으로 너무 밀려요.',
    why: '체중이 적당히 목표 쪽으로 옮겨져야 공을 힘 있게 칠 수 있어요.',
    drill: '다운스윙 시작 때 목표 쪽 발을 살짝 밟는 느낌으로, 하프 스윙 10번.',
  },
  head_sway: {
    name: '머리 좌우 이동', unit: '배', views: ['front'], range: [0, 0.3], err: 0.05, group: 2, digits: 2,
    low: '', high: '머리가 좌우로 많이 움직여요.',
    why: '머리가 많이 움직이면 공을 맞히는 위치가 매번 달라져요.',
    drill: '머리 앞에 기준점(벽, 막대)을 두고 머리가 벗어나지 않게 하프 스윙 10번.',
  },
  head_height: {
    name: '머리 높이 변화', unit: '', views: ['side', 'front', 'diag'], range: [0, 0.1], err: 0.03, group: 2, digits: 2,
    low: '', high: '임팩트 때 머리 높이가 많이 변해요.',
    why: '머리가 오르내리면 뒤땅이나 토핑이 나기 쉬워요.',
    drill: '어드레스 때 무릎 높이를 임팩트까지 유지한다는 느낌으로, 천천히 하프 스윙 10번.',
  },
  lead_arm: {
    name: '왼팔 펴짐', unit: '°', views: ['side', 'diag'], est3d: true, range: [155, 180], err: 3, group: 3, digits: 0,
    low: '백스윙 탑에서 앞쪽 팔이 많이 굽어요.', high: '',
    why: '앞팔이 펴져 있어야 스윙 반경이 일정해져요.',
    drill: '앞팔만 펴서 어깨 높이까지 천천히 올리는 3/4 스윙 10번. 팔꿈치가 굽기 전에 멈추세요.',
  },
  tempo: {
    name: '템포', unit: ':1', views: ['side', 'front', 'diag'], range: [2.3, 3.8], err: 0.2, group: 3, digits: 1,
    low: '백스윙이 너무 빨라요.', high: '백스윙에 비해 다운스윙이 느려요.',
    why: '백스윙 3 : 다운스윙 1 정도의 리듬이 일정해야 스윙이 안정돼요.',
    drill: '"하나-둘-셋"에 백스윙, "넷"에 다운스윙. 소리 내어 세면서 10번.',
  },
  spine_maintain: {
    name: '상체 각도 유지', unit: '°', views: ['side'], est3d: true, range: [0, 8], err: 3, group: 4, digits: 0,
    low: '', high: '임팩트 때 상체가 일어나거나 더 숙여져요.',
    why: '어드레스 때 숙인 각도를 유지해야 공을 정확히 맞혀요.',
    drill: '엉덩이를 벽에 대고 어드레스한 뒤, 임팩트까지 엉덩이가 벽에서 떨어지지 않게 하프 스윙 10번.',
  },
};

// 선행 관계: 앞의 것이 함께 벗어나 있으면 그것부터 고친다
export const PREREQ = {
  spine_maintain: ['posture_tilt', 'knee_flex'],
  head_sway: ['stance_width'],
  finish_balance: ['weight_shift'],
  head_height: ['knee_flex'],
};

export const VIEW_NAME = { front: '정면', side: '측면', diag: '대각선', unknown: '판별 불가' };

export function judge(code, value) {
  const d = ISSUES[code];
  if (value == null || !isFinite(value)) return { status: 'na', dist: 0 };
  const [lo, hi] = d.range;
  if (value < lo) return { status: 'low', dist: (lo - value) / d.err };
  if (value > hi) return { status: 'high', dist: (value - hi) / d.err };
  return { status: 'ok', dist: 0 };
}

export function fmt(code, v) {
  if (v == null || !isFinite(v)) return '-';
  const d = ISSUES[code];
  return v.toFixed(d.digits) + (d.unit === '°' ? '°' : d.unit === ':1' ? ' : 1' : d.unit ? ' ' + d.unit : '');
}

// 오늘 고칠 1가지 고르기: 기본기 순서 → 선행 관계 → 반복 발견 → 이탈 폭
export function pickFocus(summary) {
  const bad = Object.entries(summary)
    .filter(([, s]) => s.status === 'low' || s.status === 'high')
    .map(([code, s]) => ({ code, ...s }));
  if (!bad.length) return null;
  const badSet = new Set(bad.map((b) => b.code));
  const pool = bad.filter((b) => !(PREREQ[b.code] || []).some((p) => badSet.has(p)));
  const list = pool.length ? pool : bad;
  list.sort((a, b) =>
    ISSUES[a.code].group - ISSUES[b.code].group ||
    b.repeat - a.repeat ||
    b.dist - a.dist);
  return list[0];
}

// 재확인: 이전 기록과 비교
export function compare(prev, cur) {
  const rows = [];
  for (const code of Object.keys(ISSUES)) {
    const a = prev.summary[code], b = cur.summary[code];
    if (!a || !b || a.value == null || b.value == null) continue;
    const d = ISSUES[code];
    const change = b.value - a.value;
    let verdict;
    if (Math.abs(change) <= d.err) verdict = 'same';
    else if (b.dist < a.dist) verdict = 'better';
    else if (b.dist > a.dist) verdict = 'worse';
    else verdict = 'same';
    rows.push({ code, before: a.value, after: b.value, verdict });
  }
  const warnings = [];
  if (prev.view !== cur.view) warnings.push('촬영 각도가 달라서 비교 정확도가 낮아요.');
  if (prev.swings < 3 || cur.swings < 3) warnings.push('스윙이 3개 미만이라 참고용으로만 보세요.');
  return { rows, warnings };
}
